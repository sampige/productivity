(function ($) {
    $.fn.extend({
        GCFMathActivity: function (options) {
            return this.each(function () {
                var element = $(this);

                // Return early if this element already has a plugin instance
                if (element.data('gcfmathactivity')) return;

                // pass options to plugin constructor
                var gcfmathactivity = new GCFMathActivity(element, options);
                
                // Store plugin object in this element's data
                element.data('gcfmathactivity', gcfmathactivity);
                
                //for local testing remove "config.base"
                //config.base = (/^(f|ht)tps?:\/\//i.test(location.href)) ? config.base : "";
                //$.cachedScript(config.base +'/Modules/GCF.LearningObjects/scripts/math/' + gcfmathactivity.externalScriptFile()).done(function () {
                  
                    //initActivity(gcfmathactivity);
                //});

                var checkResults = setInterval(function () {
                if ($('.gcfMathActivity').length > 0) {
                    var currentUrl = document.URL;
                    if (currentUrl.indexOf('type=7') != -1) {
                        var timetableJS = document.createElement("script");
                        timetableJS.type = "text/javascript";
                        timetableJS.src = '../scripts/math_source/timestable.js';
                        document.body.appendChild(timetableJS);
                        //times table calls mdetect for multiplication table
                    }
                    else if (currentUrl.indexOf('type=6') != -1) {
                        var counterJS = document.createElement("script");
                        counterJS.type = "text/javascript";
                        counterJS.src = '../scripts/math_source/counter.js';
                        document.body.appendChild(counterJS);
                    }
                    else if (currentUrl.indexOf('type=8') != -1) {
                        var numberLineJS = document.createElement("script");
                        numberLineJS.type = "text/javascript";
                        numberLineJS.src = '../scripts/math_source/numberline.js';
                        document.body.appendChild(numberLineJS);
                    }
                    else {
                        var js = document.createElement("script");
                        js.type = "text/javascript";
                        js.src = '../scripts/' + gcfmathactivity.externalScriptFile();
                        document.body.appendChild(js);
                        //work for addition and subtraction.
                    }
                    setTimeout(function(){
                      initActivity(gcfmathactivity);
                    }, 900);                    
                    clearInterval(checkResults);                        
                }
                }, 50);

            });
        }
    });
    
    var GCFMathActivity = function (element, options) {
        var a = this;
        // public variables
        a.options = $.extend({
            //Set the default values
            type: 1,
            arg1: null,
            arg2: null,
            op: null,
            icon: 'bone',
            practiceMode: false,
            remainderMode: false
        }, options);

        a.activityDiv = element,
        a.answer = null,
        a.answerIsFloat = null,
        a.indexOfDecInArg1 = null,
        a.indexOfDecInArg2 = null,
        a.indexOfDecInAnswer = null,
        a.isFloatMult = null,
        a.isFloatDiv = null,
        a.betweenNumSpace = 4,
        a.canvasMarginX = 30,
        a.canvasMarginY = 12,
        a.maxAnswerLength = 3,
        a.numInputClassWidth = 45,
        a.txtFont = "bold 60px Verdana, Geneva, sans-serif",
        a.txtColor = "#00597D",
        a.highlightColor = "#0D8BBD",
        a.correctColor = "#EF853D",
        a.pencilColor = "#414F54",
        a.imgBase = "http://content.gcflearnfree.org/math/";
        a.canvas = a.activityDiv.children("canvas"),
        a.stageElements = {};
        //private variables
        var wrongAnswerTimeoutID = null,
            wrongAnswerTimeLimit = 2000,
            animActive = false;
        stage = new createjs.Stage(a.canvas.get(0));

        a.operationEnum = {
            ADD: {
                query: "add",
                symbol: "+"
            },
            SUBTRACT: {
                query: "sub",
                symbol: "-"
            },
            MULTIPLY: {
                query: "mul",
                symbol: "x"
            },
            DIVIDE: {
                query: "div",
                symbol: String.fromCharCode(247)
            },
            FRACTION: {
                query: "fra",
                symbol: "/"
            },
            DECIMAL: {
                query: "dec",
                symbol: "."
            }
        }

        var errorEnum = {
            ANSWER_PAST_MAX_LENGTH: "This equations's answer is more than " + a.maxAnswerLength + " digits.",
            INVALID_ARGUMENT: "The arguments provided for this equation are not valid.",
            INVALID_OPERATOR: "The operator for this equation is not valid.",
            INVALID_TYPE: "The activity type for this equation is invalid."
        }

        if (!$.isNumeric(a.options.type)) {
            killActivity(errorEnum.INVALID_TYPE);
            return a.activityDiv;
        }
        if (requiresArguments()) {
            if (!$.isNumeric(a.options.arg1) || !$.isNumeric(a.options.arg2)) {
                killActivity(errorEnum.INVALID_ARGUMENT);
                return 0;
            }
            setAnswer();
        }

        if (createjs.Touch.isSupported()) {
            // allow touches to work
            createjs.Touch.enable(stage, true);
        }

        a.updateStage = function () {
            stage.update();
            $('html').css("width", a.canvas.outerWidth());
            
            //createjs.Ticker.addListener(window);
            createjs.Ticker.addEventListener("tick", stage);
           
        }

        function requiresArguments() {
            return (a.options.type < 6);
        }

        function setAnswer() {
            
            a.options.arg1 = (a.options.arg1.indexOf('.') !== -1) ? ((a.options.op === a.operationEnum.MULTIPLY.query)  ? parseFloat(a.options.arg1) : parseFloat(a.options.arg1).toFixed(2)) : parseInt(a.options.arg1);
            a.options.arg2 = (a.options.arg2.indexOf('.') !== -1) ? ((a.options.op === a.operationEnum.MULTIPLY.query)  ? parseFloat(a.options.arg2) : parseFloat(a.options.arg2).toFixed(2)) : parseInt(a.options.arg2);
            
            switch (a.options.op) {
                case a.operationEnum.ADD.query:
                    a.answer = Number(a.options.arg1) + Number(a.options.arg2);
                    break;
                case a.operationEnum.SUBTRACT.query:
                    a.answer = Number(a.options.arg1) - Number(a.options.arg2);
                    break;
                case a.operationEnum.MULTIPLY.query:
                    a.answer = a.options.arg1 * a.options.arg2;
                    break;
                case a.operationEnum.DIVIDE.query:
                    a.answer = a.options.arg1 / a.options.arg2;
                    break;
                default:
                    killActivity(errorEnum.INVALID_OPERATOR);
            }

            a.indexOfDecInAnswer = a.answer.toString().indexOf('.');
            a.indexOfDecInArg1 = a.options.arg1.toString().indexOf('.');
            a.indexOfDecInArg2 = a.options.arg2.toString().indexOf('.');
            a.answerIsFloat = (a.options.op === a.operationEnum.DIVIDE.query) ? (a.indexOfDecInArg1 !== -1) : ((a.indexOfDecInAnswer !== -1) || (a.indexOfDecInArg1 !== -1) || (a.indexOfDecInArg2 !== -1));
            a.answer = a.answerIsFloat ? a.answer.toFixed(2) : a.answer;
            
            /*
            if(a.options.op !== a.operationEnum.DIVIDE.query){
                console.log('Answer:', a.answer);
            }
              */  
            /*
            if(a.answerIsFloat && (a.options.op == a.operationEnum.MULTIPLY.query)){
                a.options.arg1 = a.options.arg1.toString().replace(".","");
                a.options.arg2 = a.options.arg2.toString().replace(".","");
            }
            */

        }

        a.operator = function () {
            switch (a.options.op) {
                case a.operationEnum.ADD.query:
                    return a.operationEnum.ADD.symbol;
                case a.operationEnum.SUBTRACT.query:
                    return a.operationEnum.SUBTRACT.symbol;
                case a.operationEnum.MULTIPLY.query:
                    return a.operationEnum.MULTIPLY.symbol;
                case a.operationEnum.DIVIDE.query:
                    return a.operationEnum.DIVIDE.symbol;
                case a.operationEnum.FRACTION.query:
                    return a.operationEnum.FRACTION.symbol;
                case a.operationEnum.DECIMAL.query:
                    return a.operationEnum.DECIMAL.symbol;
                default:
                    return killActivity(errorEnum.INVALID_OPERATOR);
            }
        }

        a.externalScriptFile = function () {
            switch (parseInt(options.type)) {
                case 1:
                    return 'simplesolver.js';
                case 2:
                    return 'illustratedsolver.js';
                case 3:
                    return 'simplesetup.js';
                case 4:
                    return 'multisolver.js';
                case 5:
                    return 'multisetup.js';
                case 6:
                    return 'counter.js';
                case 7:
                    return 'timestable.js';
                case 8:
                    return 'numberline.js';
                default:
                    killActivity(errorEnum.INVALID_TYPE);
            }
        }

        a.addNumInputs = function (numOfInputs) {   

            if (!numOfInputs) numOfInputs = 1;
            var html = '';
            for (var i = 0; i < numOfInputs; i++) {
                html += '\n<input class="numInput" type="text" maxLength="1" />';
            }

            html = a.isFloatDiv ? (html += '<div id="dec">.</div>') : html;
                
            a.activityDiv.append(html);
        }
        a.lineSeparator = function (yPos, xStart, xEnd) {
            var line = new createjs.Shape();
            var g = line.graphics;
            if (!xStart) xStart = a.canvasMarginX;
            if (!xEnd){ 
                
                xEnd = (a.activityDiv.children("canvas").innerWidth() - a.canvasMarginX) - (a.isFloatMult ? 22 : 0);
            }
            g.clear();
            g.setStrokeStyle(7);
            g.beginStroke(a.txtColor);
            g.moveTo(xStart, yPos);
            g.lineTo(xEnd, yPos);
            return line;
        }

        a.bindInputEvents = function (input) {
            input.keypress(function (event) {
                var theEvent = event || window.event;
                var key = theEvent.keyCode || theEvent.which;
                key = String.fromCharCode(key);
                if (animActive) {
                    if (theEvent.preventDefault) {
                        theEvent.preventDefault();
                    }
                    return;
                }

                //handle backspace & delete in firefox
                if ($.browser.mozilla) {
                    if ((theEvent.keyCode == '8') || (theEvent.keyCode == '46')) { // backspace 8, delete 46
                        return;
                    }
                }

                //only allow numbers or '.'(if float) in input text
                if (allowInput(key)) { // is number

                    if (wrongAnswerTimeoutID != null) {
                        clearTimeout(wrongAnswerTimeoutID);
                        wrongAnswerTimeoutID = null;
                    }
                    wrongAnswerTimeoutID = setTimeout(function () {
                        a.wrongAnswerCheck(input);
                    }, wrongAnswerTimeLimit);
                } else { // not a number
                    theEvent.returnValue = false;
                    if (theEvent.preventDefault) {
                        theEvent.preventDefault();
                    }
                }
            });

            input.keyup(function (event) {

                if (input.val() == input.data("correctVal")) {
                    if (!a.options.practiceMode) {
                        clearTimeout(wrongAnswerTimeoutID);
                        animActive = true;

                        var widthAttr = parseInt(input.css('width'));
                        var heightAttr = parseInt(input.css('height'));
                        var leftAttr = parseInt(input.css('left'));
                        var topAttr = parseInt(input.css('top'));
                        
                        var scaleOffSet = 5;
                        var scaleTL = new TimelineMax({
                            delay: 0.2,
                            onStart: function () {
                                correctAnswerOnStart(input);
                            },
                            onComplete: function () {
                                correctAnswerOnComplete(input);
                            }
                        });
                        scaleTL.append(TweenLite.to(input, .1, {
                            css: {
                                width: widthAttr + scaleOffSet,
                                height: heightAttr + scaleOffSet,
                                left: leftAttr - scaleOffSet,
                                top: topAttr - scaleOffSet
                            }
                        }));
                        scaleTL.append(TweenLite.to(input, .2, {
                            css: {
                                width: widthAttr,
                                height: heightAttr,
                                left: leftAttr,
                                top: topAttr
                            }
                        }));
                        scaleTL.append(TweenLite.to(input, .4, {
                            css: {
                                borderColor: 'transparent',
                                color: a.correctColor,
                                background: 'transparent'
                            }
                        }));
                    } else checkCorrectPracticeAnswer();
                } else if (input.val().length == 0 && wrongAnswerTimeoutID != null) {
                    clearTimeout(wrongAnswerTimeoutID);
                    wrongAnswerTimeoutID = null;
                }
            });

        }

        function allowInput(key) {

            return a.answerIsFloat ? ($.isNumeric(key) || (key === '.')) : $.isNumeric(key)

        }

        function correctAnswerOnStart(input) {

            input.attr('disabled', 'disabled');
            if (typeof input.data("onCorrectStart") == 'function') input.data("onCorrectStart")(a, input);
            
            if (a.answerIsFloat && (parseInt(options.type) === 4) && (a.options.op === a.operationEnum.ADD.query)) {
               
               a.focusFirstEmptyInputDecAddMultiSolver();

            } 
            else if (a.answerIsFloat && (parseInt(options.type) === 4) && (a.options.op === a.operationEnum.SUBTRACT.query)) {
                a.focusFirstEmptyInputDecSubMultiSolver();
            }
            else if (a.answerIsFloat && (parseInt(options.type) === 4) && (a.options.op === a.operationEnum.MULTIPLY.query)) {
                a.focusFirstEmptyInputDecMultiplyMultiSolver(input);
            }     
            else {
                a.focusFirstEmptyInput();
            }

            //orgin pos (moved to top of funct) - if (typeof input.data("onCorrectStart") == 'function') input.data("onCorrectStart")(a, input);
        }

        function correctAnswerOnComplete(input) {

            animActive = false;
            input.data('correct', 'true');
            if (typeof input.data("onCorrectComplete") == 'function') input.data("onCorrectComplete")(a, input);

        }

        a.focusFirstEmptyInputDecSubMultiSolver = function () {
            var numInputs = a.activityDiv.children('input.numInput').length;
            for (var i = 0; i < numInputs; i++) {
                var nextInp = a.activityDiv.children('input.numInput').eq(i);

                if (nextInp.val().length == 0 && nextInp.data("correctVal") && nextInp.data("correctVal").toString().length > 0) {

                    var isNumLeftOfDecimal = (a.activityDiv.children('input.numInput').eq(i + 2).data("correctVal") === ".");
                    var isDecimal = nextInp.data("correctVal") === ".";

                    if (isNumLeftOfDecimal) {
                        var decCarryInp = a.activityDiv.children('input.numInput').eq(i + 1);
                        var decInp = a.activityDiv.children('input.numInput').eq(i + 2);
                        var newCarryInp = a.activityDiv.children('input.numInput').eq(i + 3);
                        var indexOfDec = a.options.arg1.toString().indexOf('.');
                        var newBorrowVal = parseInt(a.options.arg1.toString().substring(indexOfDec - 1, indexOfDec)) - 1;
                        newCarryInp.data("borrowRequired", decCarryInp.data("borrowRequired"));
                        newCarryInp.data("borrowComplete", decCarryInp.data("borrowComplete"));
                        a.bindInputEvents(newCarryInp.data("correctVal", newBorrowVal));
                        nextInp.data("carryInp", newCarryInp);
                        decCarryInp.data("correctVal", "");
                        decCarryInp.data('correct', 'true');
                        nextInp.data("borrowBtn").off().click(function () {
                            borrow(a, $(this), newCarryInp);
                        });

                    } else if (isDecimal) {
                        
                        nextInp.val('.').show().attr('disabled', 'disabled').css({
                            borderColor: 'transparent',
                            color: a.correctColor,
                            background: 'transparent'
                        }).data('correct', 'true');
                        a.focusFirstEmptyInputDecSubMultiSolver();
                        return true;
                    }

                    if ((nextInp.css("display") === "none") && nextInp.hasClass("carry")) {
                        nextInp = nextInp.next('.numInput');
                    }

                    nextInp.show().focus();

                    return true;
                }
            }
            // if no empty inputs were found, problem is complete
            // check to see if onFullComplete function exists
            if (typeof onFullComplete == 'function') onFullComplete(a);

        }
        
        a.focusFirstEmptyInputDecAddMultiSolver = function () {
            
            var numInputs = a.activityDiv.children('input.numInput').length;
            for (var i = 0; i < numInputs; i++) {
                var nextInp = a.activityDiv.children('input.numInput').eq(i);
               
                if (nextInp.val().length == 0 && nextInp.data("correctVal") && nextInp.data("correctVal").toString().length > 0) {
               
                    var isNumLeftOfDecimal = (a.activityDiv.children('input.numInput').eq(i + 2).data("correctVal") === ".");
                    var isDecimal = nextInp.data("correctVal") === ".";
 
                    if (isNumLeftOfDecimal) {
                       
                        var decCarryInp = a.activityDiv.children('input.numInput').eq(i + 1);
                        var decInp = a.activityDiv.children('input.numInput').eq(i + 2);
                        var newCarryInp = a.activityDiv.children('input.numInput').eq(i + 3);
                        newCarryInp.data("correctVal", decCarryInp.data("correctVal"));
                        nextInp.data("carryInp", newCarryInp);
                        decCarryInp.data("correctVal", "");
                        decCarryInp.data('correct', 'true');

                    } else if (isDecimal) {
                       
                        nextInp.val('.').show().attr('disabled', 'disabled').css({
                            borderColor: 'transparent',
                            color: a.correctColor,
                            background: 'transparent'
                        }).data('correct', 'true');
                        a.focusFirstEmptyInputDecAddMultiSolver();
                        return true;
                    }
                    
                    nextInp.show().focus();
                    return true;
                }
            }
            // if no empty inputs were found, problem is complete
            // check to see if onFullComplete function exists
            if (typeof onFullComplete == 'function') onFullComplete(a);
        }     

        a.focusFirstEmptyInputDecMultiplyMultiSolver = function (input) {
            var numInputs = a.activityDiv.children('input.numInput').length;
            for (var i = 0; i < numInputs; i++) {
                var nextInp = a.activityDiv.children('input.numInput').eq(i);
                
                if (nextInp.val().length == 0 && nextInp.data("correctVal") && nextInp.data("correctVal").toString().length > 0) {
                    
                    nextInp.data("$dec") && nextInp.data("$dec").show();    
                    nextInp.show().focus();
                    return true;
                }
            }
            // if no empty inputs were found, problem is complete
            // check to see if onFullComplete function exists
            if (typeof onFullComplete == 'function'){
                a.answerIsFloat && input.val(input.val() + '.');
                onFullComplete(a);

            }
        }

        a.focusFirstEmptyInput = function () {
            var numInputs = a.activityDiv.children('input.numInput').length;
            for (var i = 0; i < numInputs; i++) {
                var nextInp = a.activityDiv.children('input.numInput').eq(i);
                
                if (nextInp.val().length == 0 && nextInp.data("correctVal") && nextInp.data("correctVal").toString().length > 0) {
                    
                    nextInp.data("$dec") && nextInp.data("$dec").show();    
                    nextInp.show().focus();
                    return true;
                }
            }
            // if no empty inputs were found, problem is complete
            // check to see if onFullComplete function exists
            if (typeof onFullComplete == 'function') onFullComplete(a);
        }

        a.wrongAnswerCheck = function (input) {
            if (!options.practiceMode) {
                if (input.val() != input.data("correctVal")) {
                    clearTimeout(wrongAnswerTimeoutID);
                    animateWrongAnswer(input);
                }
            } else {
                var allAnswered = true,
                    allCorrect = true;
                a.activityDiv.children(".numInput").not(".carry").each(function () {
                    if ($(this).val().toString().length == 0 && $(this).data('correctVal').toString().length > 0) allAnswered = false;
                    if ($(this).val() != $(this).data('correctVal')) allCorrect = false;
                });
                if (allAnswered && !allCorrect) {
                    clearTimeout(wrongAnswerTimeoutID);
                    a.activityDiv.children(".numInput").not(".carry").not(".saved").each(function () {
                        animateWrongAnswer($(this))
                    });
                }
            }
        }

        function animateWrongAnswer(input) {
            TweenLite.to(input, .5, {
                css: {
                    color: 0xFFFFFF
                },
                onStart: wrongAnswerOnStart,
                onComplete: function () {
                    wrongAnswerOnComplete(input);
                }
            });
            var origX = parseInt(input.css("left")),
                wiggleTL = new TimelineMax({});

            wiggleTL.append(TweenLite.to(input, .1, {
                css: {
                    left: origX - 5
                }
            }));
            wiggleTL.append(TweenLite.to(input, .1, {
                css: {
                    left: origX + 5
                }
            }));
            wiggleTL.append(TweenLite.to(input, .1, {
                css: {
                    left: origX - 5
                }
            }));
            wiggleTL.append(TweenLite.to(input, .1, {
                css: {
                    left: origX + 5
                }
            }));
            wiggleTL.append(TweenLite.to(input, .1, {
                css: {
                    left: origX
                }
            }));
        }

        function wrongAnswerOnStart() {
            animActive = true;
        }

        function wrongAnswerOnComplete(input) {
            input.val('');
            input.focus();
            input.css('color', '#96B9C8');
            animActive = false;
        }

        function killActivity(errorMsg) {
            errorMsg = errorMsg && errorMsg.length > 1 ? errorMsg : 'There was an error initializing the activity.';
            a.activityDiv.html('<p style="padding:20px; color:#888; font-size:13px; font-weight:normal;">' + errorMsg + '</p>');
            return 0;
        }

        function checkCorrectPracticeAnswer() {
            if (!options.practiceMode) return false;
            var correctAnswer = true;
            a.activityDiv.children(".numInput").not(".carry").each(function () {
                if ($(this).val() != $(this).data('correctVal')) correctAnswer = false;
            });
            if (correctAnswer) {
                a.activityDiv.children(".numInput").not(".carry").attr("disabled", "disabled");
                
                var scaleTL = new TimelineMax({
                    delay: 0.2
                })
                scaleTL.append(TweenLite.to(a.activityDiv.children(".numInput").not(".carry"), .4, {
                    css: {
                        borderColor: 'transparent',
                        color: a.correctColor,
                        background: 'transparent'
                    }
                }));

                // check to see if onFullComplete function exists
                if (typeof onFullComplete == 'function') onFullComplete(a);
            }
        }

    }
})(jQuery);

function tick() {
    stage.update();
}