﻿function closeBrowser() { window.location.href = 'default.html'; }
function printSheet() { window.open('printable.pdf', 'printable', 'width=1000,height=700,menubar=no,toolbar=no,status=no,location=no,scrollbars=yes,resizable=yes,directories=no,copyhistory=no', true); }
function movieReplay() { window.location.reload(); }