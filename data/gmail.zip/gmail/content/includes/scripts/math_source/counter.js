﻿var counterWidth = 265,
    counterHeight = 287,
    spawnImgFile = "bean_white.png",
    countImgFile = "bean_gray.png",
    spawnObjectX = 187,
    spawnObjectY = 16;

function initActivity(a) {
    a.canvas.attr("width", counterWidth).attr("height", counterHeight);
    stage.enableMouseOver(10);
    stage.mouseMoveOutside = true;

    // load count images
    loadSpawnObject(a);
    a.updateStage();
}

function loadSpawnObject(a) {
    var spawnImage = new Image();
    spawnImage.onload = function () { loadCountObject(a, spawnImage); };
    spawnImage.crossOrigin = '';
    spawnImage.src = a.imgBase + "icons/" + spawnImgFile;
}

function loadCountObject(a, spawnImage) {
    var countImage = new Image();
    countImage.onload = function () { initSpawnObject(a, spawnImage, countImage); };
    countImage.crossOrigin = '';
    countImage.src = a.imgBase + "icons/" + countImgFile;
}


function initSpawnObject(a, spawnImage, countImage) {
    var spawnObject = new createjs.Bitmap(spawnImage);
    spawnObject.x = spawnObjectX;
    spawnObject.y = spawnObjectY;
    stage.addChild(spawnObject);

    createHelp();
    createNewCountObject(a, spawnImage, countImage);
}

function createHelp() {

    var questionMarkTxt = new createjs.Text("?", "normal 18px Verdana, Geneva, sans-serif", "#00597D");
    questionMarkTxt.textBaseline = "bottom";
    questionMarkTxt.x = 5;
    questionMarkTxt.y = counterHeight - 3;

    var helpTxt = new createjs.Text("Move beans out of box to delete", "normal 14px Verdana, Geneva, sans-serif", "#00597D");
    helpTxt.textBaseline = "bottom";
    helpTxt.x = questionMarkTxt.x + questionMarkTxt.getMeasuredWidth() + 5;
    helpTxt.y = counterHeight - 5;
    helpTxt.alpha = 0;

    var questionMarkTxtBtn = new createjs.Shape();
    var g = questionMarkTxtBtn.graphics;
    g.beginFill("#c0d4dd");
    g.rect(0, questionMarkTxt.y - questionMarkTxt.getMeasuredHeight() - 4, 25, 25);
    g.endFill();

    if (createjs.Touch.isSupported()) {
        questionMarkTxtBtn.onPress = function () {
            helpTxt.alpha = (helpTxt.alpha == 1) ? 0 : 1;
        }
    }
    else {
        questionMarkTxtBtn.onMouseOver = function () {
            helpTxt.alpha = 1;
        }

        questionMarkTxtBtn.onMouseOut = function () {
            helpTxt.alpha = 0;
        }
    }

    stage.addChild(questionMarkTxtBtn);
    stage.addChild(questionMarkTxt);
    stage.addChild(helpTxt);
}

function createNewCountObject(a, spawnImage, countImage) {

    var ctObj = new createjs.Bitmap(countImage);
    ctObj.x = spawnObjectX;
    ctObj.y = spawnObjectY;
    ctObj.alpha = 0.01;
    ctObj.didReplaceSelf = false;
    stage.addChild(ctObj);

    ctObj.onPress = function (evt) {
        // bump the target in front of it's siblings:
        var offset = { x: this.x - evt.stageX, y: this.y - evt.stageY };
        this.alpha = 1;

        // add a handler to the event object's onMouseMove callback
        // this will be active until the user releases the mouse button:
        evt.onMouseMove = function (ev) {
            this.target.x = ev.stageX + offset.x;
            this.target.y = ev.stageY + offset.y;

            //mouse outside stage turn off
            if ((ev.rawX > a.canvas.outerWidth()) || (ev.rawX < 0) || (ev.rawY > a.canvas.outerHeight()) || (ev.rawY < 0)) {
                this.target.visible = false;
            }
            else {
                this.target.visible = true;
            }

        }

        evt.onMouseUp = function (ev) {
            //called once to replace itself
            if (!this.target.didReplaceSelf) {
                this.target.didReplaceSelf = true;
                createNewCountObject(a, spawnImage, countImage);
            }


            // make sure x & y of target doesn't overlap spawning area
            if (this.target.x >= spawnObjectX) {
                if (this.target.y <= spawnObjectY) {
                    this.target.x = (spawnObjectX - spawnImage.width);
                    this.target.y = (this.target.y <= 0) ? 0 : this.target.y;
                }
                else if ((this.target.y >= spawnObjectY) && (this.target.y <= (spawnObjectY + spawnImage.height))) {
                    this.target.y = (spawnObjectY + spawnImage.height);
                }
            }

            else if (((this.target.x + spawnImage.width) >= spawnObjectX) && (this.target.y <= spawnObjectY + spawnImage.height)) {
                this.target.x = (spawnObjectX - spawnImage.width);
                this.target.y = (this.y <= 0) ? 0 : this.target.y;
            }

            //if invisible, it's been moved off stage, so delete
            if (!this.target.visible) {
                stage.removeChild(this.target);
            }

        }

    }

    if (!createjs.Touch.isSupported()) {
        ctObj.onMouseOver = function () {
            a.canvas.css("cursor", "pointer");
        }

        ctObj.onMouseOut = function () {
            a.canvas.css("cursor", "default");
        }
    }

}