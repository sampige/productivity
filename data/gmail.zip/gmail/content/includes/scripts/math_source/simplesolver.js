﻿function initActivity(a) {
    a.addNumInputs(1);
    var answerInput = a.activityDiv.children(".numInput");

    // equation
    var equationString = a.options.arg1 + " " + a.operator() + " " + a.options.arg2 + " = ";
    var equation = new createjs.Text(equationString.toString(), a.txtFont, a.txtColor);
    equation.textBaseline = "middle";
    equation.x = a.canvasMarginX;
    equation.y = a.canvasMarginY + (answerInput.height() / 2) + 3;
    stage.addChild(equation);

    answerInput.css("width", (a.answer.toString().length * a.numInputClassWidth));
    answerInput.attr("maxlength", a.answer.toString().length);
    answerInput.css("left", equation.x + equation.getMeasuredWidth() + a.betweenNumSpace);
    answerInput.css("top", a.canvasMarginY);
    //answerInput.focus();

    //canvas - width & height
    a.canvas.attr("height", answerInput.outerHeight() + (a.canvasMarginY * 2));
    a.canvas.attr("width", answerInput.position().left + answerInput.outerWidth() + a.canvasMarginX);

    //textInputEvents();
    a.bindInputEvents(answerInput.data("correctVal", a.answer));
    a.updateStage();
}