﻿function initActivity(a) {
    a.addNumInputs(2);

    var inp1 = a.activityDiv.children(".numInput").eq(0),
        inp2 = a.activityDiv.children(".numInput").eq(1),
        operatorText = new createjs.Text(a.operator().toString(), a.txtFont, a.txtColor),
        maxArgDigits = Math.max(a.options.arg1.toString().length, a.options.arg2.toString().length);

    inp1.css("width", 43 * maxArgDigits).attr("maxLength", 4).css("text-align", "right");
    inp2.css("width", 43 * maxArgDigits).attr("maxLength", 4).css("text-align", "right");
    //adjust canvas width
    a.canvas.attr("width", 2 * a.canvasMarginX + operatorText.getMeasuredWidth() + a.betweenNumSpace + inp1.outerWidth());

    inp1.css("left", a.canvas.outerWidth() - a.canvasMarginX - inp1.outerWidth()).css("top", a.canvasMarginY);
    inp2.css("left", inp1.position().left).css("top", inp1.position().top + inp1.outerHeight());
    operatorText.x = a.canvasMarginX;
    operatorText.y = inp2.position().top - 2;
    var line = a.lineSeparator(inp2.position().top + inp2.outerHeight() + 3);
    stage.addChild(operatorText, line);

    a.bindInputEvents(inp1.data("correctVal", a.options.arg1));
    a.bindInputEvents(inp2.data("correctVal", a.options.arg2));

    a.canvas.attr("height", inp2.position().top + inp2.outerHeight() + 10 + a.canvasMarginY);

    a.updateStage();
}