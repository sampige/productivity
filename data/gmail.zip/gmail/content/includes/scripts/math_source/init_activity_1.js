﻿(function ($) {
    $.fn.extend({

        //pass the options variable to the function
        GCFMathActivity: function (options) {
            var options = $.extend({
                //Set the default values
                type: 1,
                arg1: null,
                arg2: null,
                op: null,
                icon: 'bone',
                practiceMode: false
            }, options);
            
            var activityDiv = this,
                answer = null,
                betweenNumSpace = 4,
                iconAnswerGap = 10,
                canvasMarginX = 30,
                canvasMarginY = 12,
                maxAnswerLength = 3,
                numInputClassWidth = 45,
                wrongAnswerTimeoutID = null,
                wrongAnswerTimeLimit = 2000,
                animActive = false,
                leftIconsArray = [],
                rightIconsArray = [],
                stageElements = {},
                txtFont = "bold 60px Verdana, Geneva, sans-serif",
                txtColor = "#00597D",
                pencilColor = "#414F54",
                canvas = activityDiv.children("canvas"),
                scriptBase = config.base + 'includes/jscript/source/math/';
            stage = new createjs.Stage(canvas.get(0));

            var operationEnum = {
                ADD: { query: "add", symbol: "+" },
                SUBTRACT: { query: "sub", symbol: "-" },
                MULTIPLY: { query: "mul", symbol: "×" },
                DIVIDE: { query: "div", symbol: "÷" },
                FRACTION: { query: "fra", symbol: "/" },
                DECIMAL: { query: "dec", symbol: "." }
            }

            var errorEnum = {
                ANSWER_PAST_MAX_LENGTH: "This equations's answer is more than " + maxAnswerLength + " digits.",
                INVALID_ARGUMENT: "One of the arguments of this equation is invalid.",
                INVALID_OPERATOR: "The operator for this equation is invalid.",
                INVALID_TYPE: "The activity type for this equation is invalid."
            }

            if (!$.isNumeric(options.type)) {
                killActivity(errorEnum.INVALID_TYPE);
                return activityDiv;
            }
            if (!$.isNumeric(options.arg1) || !$.isNumeric(options.arg2)) {
                killActivity(errorEnum.INVALID_ARGUMENT);
                return 0;
            }
            setAnswer();

            if (createjs.Touch.isSupported()) {
                // allow touches to work
                createjs.Touch.enable(stage, true);
            }

            switch (parseInt(options.type)) {
                case 1:
                    $.cachedScript(scriptBase + 'simplesolver.js');
                    //initProblemSolver();
                    break;
                case 2:
                    var iconImg = new Image();
                    iconImg.onload = function () { initIllustratedSolver(iconImg); };
                    iconImg.src = 'http://assets.gcflearnfree.org/math/icons/' + options.icon + '.png';
                    break;
                case 3:
                    initProblemSetup();
                    break;
                case 4:
                    initMultiDigitSolver();
                    break;
                case 5:
                    initMultiDigitSetup();
                    break;
                default:
                    killActivity(errorEnum.INVALID_TYPE);
            }
            
            function updateStage() {
                stage.update();
                $('html').css("width", canvas.outerWidth());
                createjs.Ticker.addListener(window);
            }

            function setAnswer() {
                // set answer and make adjustments to answerNumInput
                options.arg1 = parseInt(options.arg1);
                options.arg2 = parseInt(options.arg2);

                switch (options.op) {
                    case operationEnum.ADD.query:
                        answer = options.arg1 + options.arg2;
                        break;
                    case operationEnum.SUBTRACT.query:
                        answer = options.arg1 - options.arg2;
                        break;
                    case operationEnum.MULTIPLY.query:
                        answer = options.arg1 * options.arg2;
                        break;
                    case operationEnum.DIVIDE.query:
                        answer = options.arg1 / options.arg2;
                        break;
                    default:
                        killActivity(errorEnum.INVALID_OPERATOR);
                }
            }

            function operator() {
                switch (options.op) {
                    case operationEnum.ADD.query:
                        return operationEnum.ADD.symbol;
                    case operationEnum.SUBTRACT.query:
                        return operationEnum.SUBTRACT.symbol;
                    case operationEnum.MULTIPLY.query:
                        return operationEnum.MULTIPLY.symbol;
                    case operationEnum.DIVIDE.query:
                        return operationEnum.DIVIDE.symbol;
                    case operationEnum.FRACTION.query:
                        return operationEnum.FRACTION.symbol;
                    case operationEnum.DECIMAL.query:
                        return operationEnum.DECIMAL.symbol;
                    default:
                        return killActivity(errorEnum.INVALID_OPERATOR);
                }
            }

            function initMultiDigitSolver() {
                var arg1Text = new createjs.Text(options.arg1.toString(), txtFont, txtColor),
                    arg2Text = new createjs.Text(options.arg2.toString(), txtFont, txtColor),
                    operatorText = new createjs.Text(operator().toString(), txtFont, txtColor),
                    maxArgDigits = Math.max(options.arg1.toString().length, options.arg2.toString().length),
                    maxArgWidth = Math.max(arg1Text.getMeasuredWidth(), arg2Text.getMeasuredWidth()),
                    argCharWidth = maxArgWidth / maxArgDigits;

                //adjust canvas width
                canvas.attr("width", 2 * canvasMarginX + operatorText.getMeasuredWidth() + betweenNumSpace + maxArgWidth);

                // addition and subtraction setup
                if (options.op == operationEnum.ADD.query || options.op == operationEnum.SUBTRACT.query) {
                    // create inputs for answer and carry digits
                    //   number of answer inputs will always equal number of digits in larger argument
                    //   number of carry digits will always equal number of digits in larger argument - 1
                    activityDiv.append(numberInputHTML(maxArgDigits * 2 - 1));

                    // set carry inputs
                    for (var i = 1; i < maxArgDigits * 2 - 1; i += 2) {
                        var inp = activityDiv.children(".numInput").eq(i);
                        inp.addClass("carry");
                        inp.css("left", canvas.outerWidth() - canvasMarginX - argCharWidth * (i + 3) / 2 + (argCharWidth - inp.outerWidth()) / 2);
                        inp.css("top", canvasMarginY);
                        if (!options.practiceMode || options.op == operationEnum.SUBTRACT.query) {
                            inp.hide();

                            var carryColumn = (i + 1) / 2;

                            if (options.op == operationEnum.ADD.query) {
                                // if current column has the possibility of needing a carry digit, check if the sum of digits in columns to right of carry digit requires a carry digit                
                                if (i / 2 < options.arg1.toString().length && i / 2 < options.arg2.toString().length) {
                                    // if the sum of digits in columns to right of carry digit requires a carry digit, bind 1 as correct input                   
                                    var partialSum = parseInt(options.arg1.toString().substring(options.arg1.toString().length - carryColumn)) + parseInt(options.arg2.toString().substring(options.arg2.toString().length - carryColumn));
                                    if (partialSum.toString().length > carryColumn)
                                        bindInputEvents(inp.data("correctVal", 1));                                        
                                    else // otherwise bind 0 as correct input
                                        bindInputEvents(inp.data("correctVal", 0));
                                }
                                else // otherwise bind 0 as correct input
                                    bindInputEvents(inp.data("correctVal", 0));
                            }
                            else if (options.op == operationEnum.SUBTRACT.query) {
                                // see if borrow is needed for column
                                if (parseInt(options.arg2.toString().substring(options.arg2.toString().length - carryColumn)) > parseInt(options.arg1.toString().substring(options.arg1.toString().length - carryColumn))) {
                                    inp.data("borrowRequired", true);
                                    bindInputEvents(inp.data("correctVal", parseInt(options.arg1.toString().charAt(options.arg1.toString().length - carryColumn - 1)) - 1));
                                    // on correct complete automatically call borrow function if in practice mode
                                }
                                else
                                    inp.data("borrowRequired", false);
                            }
                        }
                    }

                    arg1Text.x = canvas.outerWidth() - canvasMarginX - arg1Text.getMeasuredWidth();
                    arg1Text.y = activityDiv.children(".numInput").eq(1).position().top + activityDiv.children(".numInput").eq(1).outerHeight();
                    arg2Text.x = canvas.outerWidth() - canvasMarginX - arg2Text.getMeasuredWidth();
                    arg2Text.y = arg1Text.y + arg1Text.getMeasuredHeight() - 10;
                    operatorText.x = canvasMarginX;
                    operatorText.y = arg2Text.y - 2;
                    var line = lineSeparator(arg2Text.y + arg2Text.getMeasuredHeight() + 3);
                    stage.addChild(arg1Text, operatorText, arg2Text, line);

                    // set answer inputs
                    for (var i = 0; i < maxArgDigits * 2 - 1; i += 2) {
                        var inp = activityDiv.children(".numInput").eq(i);
                        inp.css("left", canvas.outerWidth() - canvasMarginX - argCharWidth * (i / 2 + 1) + (argCharWidth - inp.outerWidth()) / 2);
                        inp.css("top", Math.floor(arg2Text.y + arg2Text.getMeasuredHeight() + 8));
                        // if adding and input is for first (far left) digit, allow two digit answers and no carry
                        if (options.op == operationEnum.ADD.query && i == maxArgDigits * 2 - 2) {
                            inp.css("width", inp.innerWidth() + argCharWidth)
                               .css("left", inp.position().left - argCharWidth - 2)
                               .css("text-align", "right")
                               .css("padding-right", "4px")
                               .attr("maxlength", 2)
                               .data("correctVal", answer.toString().substring(0, answer.toString().length - i / 2));
                            if (inp.data("correctVal").length > 0)
                                bindInputEvents(inp, checkCorrectPracticeAnswer);                            
                        }
                        else { // if input does not correspond to the first (far left) digit for addition, only accept one digit and allow carry digit to be entered
                            inp.data("correctVal", answer.toString().charAt(answer.toString().length - i / 2 - 1));
                            if (options.op == operationEnum.ADD.query)
                                inp.data("carryInp", activityDiv.children(".numInput").eq(i + 1));
                            else if (options.op == operationEnum.SUBTRACT.query && inp.next('.carry').length) {
                                var btn = addBorrowButton(inp);
                                if (!options.practiceMode && i > 0)
                                    btn.hide();
                                inp.data("onCorrectStart", completeBorrow);
                                inp.focus(function () { if(!$(this).data("borrowComplete")) $(this).data("borrowBtn").show(); });
                            }
                            bindInputEvents(inp, checkCorrectPracticeAnswer);
                        }
                        if (!options.practiceMode && i > 0)
                            inp.hide();
                        inp.focus(function () { if ($(this).data("carryInp")) $(this).data("carryInp").show(); });
                        //inp.blur(function () { if ($(this).data("carryInp") && $(this).val().length == 0 && $(this).data("carryInp").val().length == 0) $(this).data("carryInp").hide(); });
                    }

                    canvas.attr("height", activityDiv.children(".numInput").eq(0).position().top + activityDiv.children(".numInput").eq(0).outerHeight() + canvasMarginY);
                }
                updateStage();
            }
            function initIllustratedSolver(iconImg) {
                activityDiv.append(numberInputHTML(3));
                var canvas = activityDiv.children("canvas"),
                    leftInput = activityDiv.children(".numInput").eq(0),
                    rightInput = activityDiv.children(".numInput").eq(1),
                    answerInput = activityDiv.children(".numInput").eq(2);
                stage = new createjs.Stage(canvas.get(0));

                canvas.attr("height", canvasMarginY * 2 + leftInput.outerHeight() + (iconImg.height * Math.max(options.arg1, options.arg2)) + (iconAnswerGap * Math.max(options.arg1, options.arg2)));

                //bg
                //bg = new createjs.Shape();
                //bg.graphics.beginFill('#FFFFFF').drawRect(0, 0, 1, 1).endFill();
                //stage.addChild(bg);
                //stageElements['bg'] = bg;
                
                leftInput.css("left", canvasMarginX);
                leftInput.css("top", canvas.outerHeight() - leftInput.outerHeight() - canvasMarginY);

                bindInputEvents(leftInput.data("correctVal", options.arg1), displayFullEquationCheck);

                operationObj = new createjs.Text(operator(), txtFont, txtColor);
                operationObj.x = leftInput.position().left + +leftInput.outerWidth() + betweenNumSpace;
                operationObj.textBaseline = "middle";
                operationObj.y = leftInput.position().top + leftInput.outerHeight() / 2 - 2;
                stage.addChild(operationObj);

                rightInput.css("left", operationObj.x + operationObj.getMeasuredWidth() + betweenNumSpace);
                rightInput.css("top", leftInput.position().top);
                bindInputEvents(rightInput.data("correctVal", options.arg2), displayFullEquationCheck);

                eqSign = new createjs.Text("=", txtFont, txtColor);
                eqSign.x = rightInput.position().left + rightInput.outerWidth() + betweenNumSpace;
                eqSign.textBaseline = "middle";
                eqSign.y = operationObj.y;
                eqSign.alpha = 0;
                stage.addChild(eqSign);
                stageElements['eqSign'] = eqSign;
                
                setAnswer();
                answerInput.css("width", (answer.toString().length * numInputClassWidth));
                answerInput.attr("maxlength", answer.toString().length);
                answerInput.css("left", eqSign.x + eqSign.getMeasuredWidth() + betweenNumSpace);
                answerInput.css("top", leftInput.position().top);
                bindInputEvents(answerInput.data("correctVal", answer), function() { moveIconsToAnswer(iconImg.width); });
                var answerInputStageElm = new createjs.DOMElement(answerInput.get(0));
                answerInputStageElm.alpha = 0;
                stage.addChild(answerInputStageElm);
                stageElements['answerInput'] = answerInputStageElm;


                //draw left icons
                var leftIconX = leftInput.position().left + ((leftInput.outerWidth() - iconImg.width) / 2);
                for (var i = 0; i < options.arg1; i++) {
                    leftIconsArray[i] = new createjs.Bitmap(iconImg);
                    leftIconsArray[i].x = leftIconX;
                    leftIconsArray[i].y = (i == 0) ? canvasMarginY : (leftIconsArray[i-1].y + iconImg.height + iconAnswerGap);
                    stage.addChild(leftIconsArray[i]);
                }

                //draw right icons
                var rightIconX = rightInput.position().left + ((rightInput.outerWidth() - iconImg.width) / 2);
                for (var i = 0; i < options.arg2; i++) {
                    rightIconsArray[i] = new createjs.Bitmap(iconImg);
                    rightIconsArray[i].x = rightIconX;
                    rightIconsArray[i].y = (i == 0) ? canvasMarginY : (rightIconsArray[i-1].y + iconImg.height + iconAnswerGap);
                    stage.addChild(rightIconsArray[i]);
                }

                //bg.scaleY = canvas.outerHeight();
                //bg.scaleX = rightInput.position().left + rightInput.outerWidth() + canvasMarginX;

                // if icons when moved for answer are wider than answer input, make sure canvas is large enough to properly display the icons
                if (answerIconsWidth(iconImg.width) > activityDiv.children(".numInput").eq(2).outerWidth())
                    canvas.attr("width", answerInput.position().left + answerInput.outerWidth() / 2 + answerIconsWidth(iconImg.width) / 2 + canvasMarginX);
                else
                    canvas.attr("width", answerInput.position().left + answerInput.outerWidth() + canvasMarginX);

                updateStage();
            }
            function initProblemSetup() {
                activityDiv.append(numberInputHTML(2));
                var leftInput = activityDiv.children(".numInput").eq(0),
                    rightInput = activityDiv.children(".numInput").eq(1);

                leftInput.css("left", canvasMarginX);
                leftInput.css("top", canvasMarginY);
                bindInputEvents(leftInput.data("correctVal", options.arg1));

                operationObj = new createjs.Text(operator(), txtFont, txtColor);
                operationObj.x = leftInput.position().left + leftInput.outerWidth() + betweenNumSpace;
                operationObj.textBaseline = "middle";
                operationObj.y = leftInput.position().top + leftInput.outerHeight() / 2 - 2;
                stage.addChild(operationObj);

                rightInput.css("left", operationObj.x + operationObj.getMeasuredWidth() + betweenNumSpace + 1);
                rightInput.css("top", canvasMarginY);
                bindInputEvents(rightInput.data("correctVal", options.arg2));

                canvas.attr("height", rightInput.outerHeight() + (canvasMarginY * 2));
                canvas.attr("width", rightInput.position().left + rightInput.outerWidth() + canvasMarginX);

                updateStage();
            }
            function initMultiDigitSetup() {
                activityDiv.append(numberInputHTML(2));

                var inp1 = activityDiv.children(".numInput").eq(0),
                    inp2 = activityDiv.children(".numInput").eq(1),
                    operatorText = new createjs.Text(operator().toString(), txtFont, txtColor),
                    maxArgDigits = Math.max(options.arg1.toString().length, options.arg2.toString().length);

                inp1.css("width", 43 * maxArgDigits).attr("maxLength", 4).css("text-align", "right");
                inp2.css("width", 43 * maxArgDigits).attr("maxLength", 4).css("text-align", "right");
                //adjust canvas width
                canvas.attr("width", 2 * canvasMarginX + operatorText.getMeasuredWidth() + betweenNumSpace + inp1.outerWidth());

                inp1.css("left", canvas.outerWidth() - canvasMarginX - inp1.outerWidth()).css("top", canvasMarginY);
                inp2.css("left", inp1.position().left).css("top", inp1.position().top + inp1.outerHeight());
                operatorText.x = canvasMarginX;
                operatorText.y = inp2.position().top - 2;
                var line = lineSeparator(inp2.position().top + inp2.outerHeight() + 3);
                stage.addChild(operatorText, line);

                bindInputEvents(inp1.data("correctVal", options.arg1));
                bindInputEvents(inp2.data("correctVal", options.arg2));

                canvas.attr("height", inp2.position().top + inp2.outerHeight() + 10 + canvasMarginY);

                updateStage();
            }
            function numberInputHTML(numOfInputs) {
                if (!numOfInputs) numOfInputs = 1;
                var html = '';
                for (var i = 0; i < numOfInputs; i++) {
                    html += '\n<input class="numInput" type="text" maxLength="1" />';
                }
                return html;
            }
            function lineSeparator(yPos) {
                var line = new createjs.Shape();
                var g = line.graphics;
                g.clear();
                var linePixelHgt = 7;
                g.setStrokeStyle(linePixelHgt);
                g.beginStroke(txtColor);
                var lineY = yPos;
                g.moveTo(canvasMarginX, lineY);
                g.lineTo(activityDiv.children("canvas").innerWidth() - canvasMarginX, lineY);
                return line;
            }
            function addBorrowButton(input) {                
                var borrowInp = input.next('.numInput')
                var btn = $('<img src="http://assets.gcflearnfree.org/math/borrow.png" />');
                activityDiv.append(btn);
                btn.css("position", "absolute").css("left", input.position().left - 4).css("top", input.position().top - 1).css("cursor", "pointer").css("z-index", "80")
                   .mouseover(function () { this.src = this.src.replace(".png", "_over.png"); }).mouseout(function () { this.src = this.src.replace("_over.png", ".png"); })
                   .click(function () { borrow($(this), borrowInp); } );

                input.data("borrowBtn", btn);
                return btn;
            }
            function completeBorrow(inp) {
                var borrowInp = inp.next('.numInput')
                if (borrowInp.val().toString().length == 0) {
                    inp.data("borrowBtn").fadeOut(50);
                    borrowInp.css("borderColor", "transparent").css("color", pencilColor).css("background", "transparent");
                    if (borrowInp.data("borrowRequired")) {
                        borrowInp.show();
                        borrowInp.val(borrowInp.data('correctVal'));
                        if (!inp.data("borrowComplete")) createBorrowSlashAndOne(borrowInp);
                    }
                    else
                        borrowInp.val(' ');
                    inp.data("borrowComplete", true);
                    correctAnswerOnStart(borrowInp);
                }
            }
            function createBorrowSlashAndOne(borrowInp) {
                slash = new createjs.Text("\\", "bold 56px Verdana, Geneva, sans-serif", pencilColor);
                slash.alpha = .85;
                slash.x = borrowInp.position().left - 9;
                slash.y = borrowInp.position().top + borrowInp.outerHeight() - 10;

                borrowOne = new createjs.Text("1", "28px Verdana, Geneva, sans-serif", pencilColor);
                borrowOne.x = borrowInp.position().left + borrowInp.outerWidth() + 10;
                borrowOne.y = borrowInp.position().top + borrowInp.outerHeight() - 13;

                //if (borrowInp.prev().prev().data("borrowRequired")) {
                //    borrowOne.y = borrowOne.y - 8;
                //    borrowOne.x = borrowOne.x + 3;
                //}
                //    borrowOne.x = borrowInp.position().left + borrowInp.outerWidth() + 8;

                borrowOne.textBaseline = "top";
                borrowOne.textAlign = "center";

                stage.addChild(slash, borrowOne);
            }
            function borrow(borrowBtn, borrowInp) {
                borrowInp.show().focus();
                borrowBtn.fadeOut(150);
                if (borrowInp.data("borrowRequired")) {
                    createBorrowSlashAndOne(borrowInp);
                    borrowInp.prev().data("borrowComplete", true);
                } else {
                    setTimeout(function () {
                        wrongAnswerCheck(borrowInp);                    
                        borrowInp.delay(500).fadeOut(100, function () { focusFirstEmptyInput(); borrowBtn.fadeIn(50); });
                    }, 400);
                }
            }

            function bindInputEvents(input, onCorrect) {
                input.keypress(function (event) {
                    var theEvent = event || window.event;
                    var key = theEvent.keyCode || theEvent.which;
                    key = String.fromCharCode(key);
                    if (animActive) {
                        if (theEvent.preventDefault) {
                            theEvent.preventDefault();
                        }
                        return;
                    }
                    
                    if (wrongAnswerTimeoutID != null) {
                        clearTimeout(wrongAnswerTimeoutID);
                        wrongAnswerTimeoutID = null;
                    }

                    //handle backspace & delete in firefox
                    if ($.browser.mozilla) {
                        if ((theEvent.keyCode == '8') || (theEvent.keyCode == '46')) { // backspace 8, delete 46
                            return;
                        }
                    }

                    //only allow numbers in input text
                    if ($.isNumeric(key)) { // is number
                        wrongAnswerTimeoutID = setTimeout(function () { wrongAnswerCheck(input); }, wrongAnswerTimeLimit);
                    }
                    else { // not a number
                        theEvent.returnValue = false;
                        if (theEvent.preventDefault) {
                            theEvent.preventDefault();
                        }

                    }
                });

                input.keyup(function (event) {
                    if (input.val() == input.data("correctVal")) {
                        if (!options.practiceMode) {
                            clearTimeout(wrongAnswerTimeoutID);
                            animActive = true;

                            var widthAttr = parseInt(input.css('width'));
                            var heightAttr = parseInt(input.css('height'));
                            var leftAttr = parseInt(input.css('left'));
                            var topAttr = parseInt(input.css('top'));

                            var scaleOffSet = 5;
                            var scaleTL = new TimelineMax({ delay: 0.2, onStart: function () { correctAnswerOnStart(input); }, onComplete: function () { correctAnswerOnComplete(input, onCorrect); } });
                            scaleTL.append(TweenLite.to(input, .1, { css: { width: widthAttr + scaleOffSet, height: heightAttr + scaleOffSet, left: leftAttr - scaleOffSet, top: topAttr - scaleOffSet } }));
                            scaleTL.append(TweenLite.to(input, .2, { css: { width: widthAttr, height: heightAttr, left: leftAttr, top: topAttr } }));
                            scaleTL.append(TweenLite.to(input, .4, { css: { borderColor: 'transparent', color: '#EF853D', background: 'transparent' } }));
                        }
                        else checkCorrectPracticeAnswer();
                    }
                });

            }

            function correctAnswerOnStart(input) {
                input.attr('disabled', 'disabled');
                focusFirstEmptyInput();
                if (typeof input.data("onCorrectStart") == 'function') input.data("onCorrectStart")(input);
            }

            function correctAnswerOnComplete(input, onCorrect) {
                animActive = false;
                input.data('correct', 'true');
                if (typeof onCorrect == 'function') onCorrect();
                if (typeof input.data("onCorrectComplete") == 'function') input.data("onCorrectComplete")(input);
            }

            function focusFirstEmptyInput() {
                var numInputs = activityDiv.children('input.numInput').length;
                for (var i = 0; i < numInputs; i++) {
                    var nextInp = activityDiv.children('input.numInput').eq(i);
                    if (nextInp.val().length == 0 && nextInp.data("correctVal") && nextInp.data("correctVal").toString().length > 0) {
                        nextInp.show().focus();
                        return true;
                    }
                }
            }

            function wrongAnswerCheck(input) {
                if (!options.practiceMode) {
                    if (input.val() != input.data("correctVal")) {
                        clearTimeout(wrongAnswerTimeoutID);
                        animateWrongAnswer(input);
                    }
                }
                else {
                    var allAnswered = true, allCorrect = true;
                    activityDiv.children(".numInput").not(".carry").each(function () { if ($(this).val().toString().length == 0 && $(this).data('correctVal').toString().length > 0) allAnswered = false; if ($(this).val() != $(this).data('correctVal')) allCorrect = false; });
                    if (allAnswered && !allCorrect) {
                        clearTimeout(wrongAnswerTimeoutID);
                        activityDiv.children(".numInput").not(".carry").each(function () { animateWrongAnswer($(this)) });
                    }
                }
            }
            function animateWrongAnswer(input) {
                TweenLite.to(input, .5, { css: { color: 0xFFFFFF }, onStart: wrongAnswerOnStart, onComplete: function () { wrongAnswerOnComplete(input); } });
                var origX = parseInt(input.css("left")), wiggleTL = new TimelineMax({});

                wiggleTL.append(TweenLite.to(input, .1, { css: { left: origX - 5 } }));
                wiggleTL.append(TweenLite.to(input, .1, { css: { left: origX + 5 } }));
                wiggleTL.append(TweenLite.to(input, .1, { css: { left: origX - 5 } }));
                wiggleTL.append(TweenLite.to(input, .1, { css: { left: origX + 5 } }));
                wiggleTL.append(TweenLite.to(input, .1, { css: { left: origX } }));
            }

            function wrongAnswerOnStart() {
                animActive = true;
            }

            function wrongAnswerOnComplete(input) {
                input.val('');
                input.focus();
                input.css('color', '#96B9C8');
                animActive = false;
            }
            
            function isCorrect(input) {
                return (input.data('correct') == 'true');
            }

            function killActivity(errorMsg) {
                errorMsg = errorMsg && errorMsg.length > 1 ? errorMsg : 'There was an error initializing the activity.';
                activityDiv.html('<p style="padding:20px; color:#888; font-size:13px; font-weight:normal;">' + errorMsg + '</p>');
                return 0;
            }

            function displayFullEquationCheck() {
                if (isCorrect(activityDiv.children(".numInput").eq(0)) && isCorrect(activityDiv.children(".numInput").eq(1))) {
                    var answerInput = activityDiv.children(".numInput").eq(2),
                        eq_tl = new TimelineMax({ onComplete: function () { answerInput.focus(); } });
                    //var bgWidth = answerInput.position().left + answerInput.outerWidth() + canvasMarginX;
                    //eq_tl.to(stageElements['bg'], .7, { scaleX: bgWidth }).to([stageElements['eqSign'], stageElements['answerInput']], .7, { alpha: 1 });
                    eq_tl.to([stageElements['eqSign'], stageElements['answerInput']], .7, { alpha: 1 });
                }
            }

            function answerIconsWidth(iconWidth) {
                if (options.op == operationEnum.SUBTRACT.query || options.arg1 == 0 || options.arg2 == 0)
                    return iconWidth;
                else
                    return iconWidth * 2 + iconAnswerGap;
            }

            function moveIconsToAnswer(iconWidth) {
                // fade icons if subtraction
                if (options.op == operationEnum.SUBTRACT.query) {
                    var subtractionIconsArray = [];
                    subtractionIconsArray = subtractionIconsArray.concat(rightIconsArray, leftIconsArray.slice(0, options.arg2));

                    TweenMax.to(subtractionIconsArray, 0.5, { alpha: 0 });
                    //alert(subtractionIconsArray);
                }

                //if answer 0 no rows to move
                if (answer > 0) {
                    var answerCenter = activityDiv.children(".numInput").eq(2).position().left + activityDiv.children(".numInput").eq(2).outerWidth() / 2;

                    //TweenMax.to(bg, 0.9, { scaleX: activityDiv.children("canvas").outerWidth() });
                    if (options.op == operationEnum.SUBTRACT.query || options.arg2 == 0)
                        TweenMax.to(leftIconsArray, 1, { x: answerCenter - iconWidth / 2 });
                    else if (options.arg1 == 0)
                        TweenMax.to(rightIconsArray, 1, { x: answerCenter - iconWidth / 2 });
                    else {
                        TweenMax.to(leftIconsArray, 1, { x: answerCenter - iconWidth - iconAnswerGap / 2 });
                        TweenMax.to(rightIconsArray, 1, { x: answerCenter + iconAnswerGap / 2 });
                    }
                }
            }

            function checkCorrectPracticeAnswer() {
                if (!options.practiceMode) return false;
                var correctAnswer = true;
                activityDiv.children(".numInput").not(".carry").each(function () { if ($(this).val() != $(this).data('correctVal')) correctAnswer = false; });
                if (correctAnswer) {
                        activityDiv.children(".numInput").not(".carry").attr("disabled", "disabled");
                        var scaleTL = new TimelineMax({ delay: 0.2 })
                        scaleTL.append(TweenLite.to(activityDiv.children(".numInput").not(".carry"), .4, { css: { borderColor: 'transparent', color: '#EF853D', background: 'transparent' } }));
                }
            }
            return activityDiv;
        }
    });
})(jQuery);

function tick() {
   stage.update();
}
