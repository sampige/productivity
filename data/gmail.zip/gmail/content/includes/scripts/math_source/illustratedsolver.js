﻿var iconAnswerGap = 10,
    leftIconsArray = [],
    rightIconsArray = [];

function initActivity(a) {
    var iconImg = new Image();
    iconImg.onload = function () { initIllustratedSolver(a, iconImg); };
    iconImg.src = a.imgBase + 'icons/' + a.options.icon + '.png';
}

function initIllustratedSolver(a, iconImg) {
    a.addNumInputs(3);
    var leftInput = a.activityDiv.children(".numInput").eq(0),
        rightInput = a.activityDiv.children(".numInput").eq(1),
        answerInput = a.activityDiv.children(".numInput").eq(2);
    stage = new createjs.Stage(a.canvas.get(0));

    a.canvas.attr("height", a.canvasMarginY * 2 + leftInput.outerHeight() + (iconImg.height * Math.max(a.options.arg1, a.options.arg2)) + (iconAnswerGap * Math.max(a.options.arg1, a.options.arg2)));

    //bg
    //bg = new createjs.Shape();
    //bg.graphics.beginFill('#FFFFFF').drawRect(0, 0, 1, 1).endFill();
    //stage.addChild(bg);
    //stageElements['bg'] = bg;

    leftInput.css("left", a.canvasMarginX);
    leftInput.css("top", a.canvas.outerHeight() - leftInput.outerHeight() - a.canvasMarginY);
    a.bindInputEvents(leftInput.data("correctVal", a.options.arg1).data("onCorrectComplete", displayFullEquationCheck));

    var operatorObj = new createjs.Text(a.operator(), a.txtFont, a.txtColor);
    operatorObj.x = leftInput.position().left + leftInput.outerWidth() + a.betweenNumSpace;
    operatorObj.textBaseline = "middle";
    operatorObj.y = leftInput.position().top + leftInput.outerHeight() / 2 - 2;
    stage.addChild(operatorObj);

    rightInput.css("left", operatorObj.x + operatorObj.getMeasuredWidth() + a.betweenNumSpace);
    rightInput.css("top", leftInput.position().top);
    a.bindInputEvents(rightInput.data("correctVal", a.options.arg2).data("onCorrectComplete", displayFullEquationCheck));

    var eqSign = new createjs.Text("=", a.txtFont, a.txtColor);
    eqSign.x = rightInput.position().left + rightInput.outerWidth() + a.betweenNumSpace;
    eqSign.textBaseline = "middle";
    eqSign.y = operatorObj.y;
    eqSign.alpha = 0;
    stage.addChild(eqSign);
    a.stageElements['eqSign'] = eqSign;

    answerInput.css("width", (a.answer.toString().length * a.numInputClassWidth));
    answerInput.attr("maxlength", a.answer.toString().length);
    answerInput.css("left", eqSign.x + eqSign.getMeasuredWidth() + a.betweenNumSpace);
    answerInput.css("top", leftInput.position().top);
    a.bindInputEvents(answerInput.data("correctVal", a.answer).data("onCorrectComplete", function () { moveIconsToAnswer(a, iconImg.width); }));
    var answerInputStageElm = new createjs.DOMElement(answerInput.get(0));
    answerInputStageElm.alpha = 0;
    stage.addChild(answerInputStageElm);
    a.stageElements['answerInput'] = answerInputStageElm;


    //draw left icons
    var leftIconX = leftInput.position().left + ((leftInput.outerWidth() - iconImg.width) / 2);
    for (var i = 0; i < a.options.arg1; i++) {
        leftIconsArray[i] = new createjs.Bitmap(iconImg);
        leftIconsArray[i].x = leftIconX;
        leftIconsArray[i].y = (i == 0) ? a.canvasMarginY : (leftIconsArray[i - 1].y + iconImg.height + iconAnswerGap);
        stage.addChild(leftIconsArray[i]);
    }

    //draw right icons
    var rightIconX = rightInput.position().left + ((rightInput.outerWidth() - iconImg.width) / 2);
    for (var i = 0; i < a.options.arg2; i++) {
        rightIconsArray[i] = new createjs.Bitmap(iconImg);
        rightIconsArray[i].x = rightIconX;
        rightIconsArray[i].y = (i == 0) ? a.canvasMarginY : (rightIconsArray[i - 1].y + iconImg.height + iconAnswerGap);
        stage.addChild(rightIconsArray[i]);
    }

    //bg.scaleY = canvas.outerHeight();
    //bg.scaleX = rightInput.position().left + rightInput.outerWidth() + canvasMarginX;

    // if icons when moved for answer are wider than answer input, make sure canvas is large enough to properly display the icons
    if (answerIconsWidth(a, iconImg.width) > a.activityDiv.children(".numInput").eq(2).outerWidth())
        a.canvas.attr("width", answerInput.position().left + answerInput.outerWidth() / 2 + answerIconsWidth(a, iconImg.width) / 2 + a.canvasMarginX);
    else
        a.canvas.attr("width", answerInput.position().left + answerInput.outerWidth() + a.canvasMarginX);

    a.updateStage();
}

function answerIconsWidth(a, iconWidth) {
    if (a.options.op == a.operationEnum.SUBTRACT.query || a.options.arg1 == 0 || a.options.arg2 == 0)
        return iconWidth;
    else
        return iconWidth * 2 + iconAnswerGap;
}

function isCorrect(input) {
    return (input.data('correct') == 'true');
}

function displayFullEquationCheck(a) {
    if (isCorrect(a.activityDiv.children(".numInput").eq(0)) && isCorrect(a.activityDiv.children(".numInput").eq(1))) {
        var answerInput = a.activityDiv.children(".numInput").eq(2),
            eq_tl = new TimelineMax({ onComplete: function () { answerInput.focus(); } });
        //var bgWidth = answerInput.position().left + answerInput.outerWidth() + canvasMarginX;
        //eq_tl.to(a.stageElements['bg'], .7, { scaleX: bgWidth }).to([a.stageElements['eqSign'], a.stageElements['answerInput']], .7, { alpha: 1 });
        eq_tl.to([a.stageElements['eqSign'], a.stageElements['answerInput']], .7, { alpha: 1 });
    }
}

function moveIconsToAnswer(a, iconWidth) {
    // fade icons if subtraction
    if (a.options.op == a.operationEnum.SUBTRACT.query) {
        var subtractionIconsArray = [];
        subtractionIconsArray = subtractionIconsArray.concat(rightIconsArray, leftIconsArray.slice(0, a.options.arg2));

        TweenMax.to(subtractionIconsArray, 0.5, { alpha: 0 });
        //alert(subtractionIconsArray);
    }

    //if answer 0 no rows to move
    if (a.answer > 0) {
        var answerCenter = a.activityDiv.children(".numInput").eq(2).position().left + a.activityDiv.children(".numInput").eq(2).outerWidth() / 2;

        //TweenMax.to(bg, 0.9, { scaleX: a.activityDiv.children("canvas").outerWidth() });
        if (a.options.op == a.operationEnum.SUBTRACT.query || a.options.arg2 == 0)
            TweenMax.to(leftIconsArray, 1, { x: answerCenter - iconWidth / 2 });
        else if (a.options.arg1 == 0)
            TweenMax.to(rightIconsArray, 1, { x: answerCenter - iconWidth / 2 });
        else {
            TweenMax.to(leftIconsArray, 1, { x: answerCenter - iconWidth - iconAnswerGap / 2 });
            TweenMax.to(rightIconsArray, 1, { x: answerCenter + iconAnswerGap / 2 });
        }
    }
}