﻿var boxDim = { width: 51, height: 46 },
    maxCount = 12,
    outlinesDim = { width: 3, height: 3 },
    outlinesColor = "#C7CACC",
    tableNumersBGColor = "#ECF0F3",
    tableFontColor = "#8DB3C3",
    columnRowHeaderFontColors = "#00597D",
    columnRowHeaderBGColors = { odd: "#D9E4EA", even: "#CDDCE3" },
    ROW = "row",
    COLUMN = "column",
    columnRowChosenHighlightColor = "#FBF1EA",
    columnRowChosenHighlightSpeed = 0.5,
    highLightOrange = "#EF853D",
    tableNumbers = {},
    columnNumConts = {},
    rowNumConts = {},
    selectedTableNumber,
    selectedTableNumberScale = 1.2,
    selectedTableNumberScaleSpeed = 0.2,
    columnChosenHighlighter,
    rowChosenHighlighter,
    rowHeaderSelectedName,
    columnHeaderSelectedName,
    mobilePhone = false;

function initActivity(a) {

    //$.cachedScript(config.base + 'includes/jscript/mdetect.js').done(function () { mobilePhone = DetectTierIphone(); });
    var js = document.createElement("script");
    js.type = "text/javascript";
    js.src = '../scripts/mdetect.js';
    document.body.appendChild(js);
    
    a.canvas.attr("width", boxDim.width * (maxCount + 1)).attr("height", boxDim.height * (maxCount + 1));
    stage.enableMouseOver(10);
    stage.mouseMoveOutside = true;

    createTableRowHeaders(a);
    createTableColumnHeaders(a);
    createTableNumbersBG(a);
    createColumnRowChosenHighlighters(a);
    createTableOutlines(a);
    createTableNumbers(a);

    a.updateStage();
}

function createTableRowHeaders(a) {
    for (var i = 1; i <= maxCount; i++) {
        var contName = COLUMN + i.toString();
        var rowNumCont = new createjs.Container();
        var rowBG = new createjs.Shape();
        var g = rowBG.graphics;
        g.beginFill((i % 2) ? columnRowHeaderBGColors.odd : columnRowHeaderBGColors.even);
        g.rect(0, 0, boxDim.width, boxDim.height);
        g.endFill();
        rowNumCont.name = contName;
        var text = new createjs.Text(i.toString(), "bold 30px Arial", columnRowHeaderFontColors);
        text.textBaseline = "middle";
        text.textAlign = "center";
        text.x = boxDim.width / 2;
        text.y = (boxDim.height / 2) + (outlinesDim.height / 2);

        rowNumCont.addChild(rowBG);
        rowNumCont.addChild(text);
        rowNumCont.y = (boxDim.height * i) - (outlinesDim.height / 2);
        stage.addChild(rowNumCont);

        rowNumCont.onPress = function (evt) {
            rowHeaderPressed(a, this);
        }

        if (!createjs.Touch.isSupported()) {
            rowNumCont.onMouseOver = function (evt) {
                a.canvas.css("cursor", "pointer");
                this.getChildAt(1).color = highLightOrange;
            }

            rowNumCont.onMouseOut = function (evt) {
                a.canvas.css("cursor", "default");
                this.getChildAt(1).color = columnRowHeaderFontColors;
            }

        }

        rowNumConts[contName] = rowNumCont;
    }
}

function createTableColumnHeaders(a) {
    for (var i = 1; i <= maxCount; i++) {

        var contName = ROW + i.toString();
        var colNumCont = new createjs.Container();
        var columnBG = new createjs.Shape();
        var g = columnBG.graphics;
        g.beginFill((i % 2) ? columnRowHeaderBGColors.odd : columnRowHeaderBGColors.even);
        g.rect(0, 0, boxDim.width, boxDim.height);
        g.endFill();
        colNumCont.name = contName;
        var text = new createjs.Text(i.toString(), "bold 30px Arial", columnRowHeaderFontColors);
        text.textBaseline = "middle";
        text.textAlign = "center";
        text.x = (boxDim.width / 2) - (outlinesDim.width / 2);
        text.y = boxDim.height / 2;

        colNumCont.addChild(columnBG);
        colNumCont.addChild(text);
        colNumCont.x = (boxDim.width * i) - (outlinesDim.width / 2);
        stage.addChild(colNumCont);

        colNumCont.onPress = function (evt) {
            columnHeaderPressed(a, this);
        }

        if (!createjs.Touch.isSupported()) {
            colNumCont.onMouseOver = function (evt) {
                a.canvas.css("cursor", "pointer");
                this.getChildAt(1).color = highLightOrange;
            }

            colNumCont.onMouseOut = function (evt) {
                a.canvas.css("cursor", "default");
                this.getChildAt(1).color = columnRowHeaderFontColors;
            }

        }

        columnNumConts[contName] = colNumCont;
    }

}

function createTableNumbersBG(a) {
    var tableNumersBG = new createjs.Shape();
    stage.addChild(tableNumersBG);
    var g = tableNumersBG.graphics;
    g.beginFill(tableNumersBGColor);
    g.rect(boxDim.width - (outlinesDim.height / 2), boxDim.height - (outlinesDim.width / 2), a.canvas.attr("width") - boxDim.width, a.canvas.attr("height") - boxDim.height);
    g.endFill();
}


function createColumnRowChosenHighlighters(a) {

    columnChosenHighlighter = new createjs.Shape();
    rowChosenHighlighter = new createjs.Shape();

    var highlighterX = boxDim.width - (outlinesDim.height / 2);
    var highlighterY = boxDim.height - (outlinesDim.width / 2);

    columnChosenHighlighter.graphics.beginFill(columnRowChosenHighlightColor).drawRect(0, 0, boxDim.width, 1).endFill();
    columnChosenHighlighter.y = highlighterY;
    rowChosenHighlighter.graphics.beginFill(columnRowChosenHighlightColor).drawRect(0, 0, 1, boxDim.height).endFill();
    rowChosenHighlighter.x = highlighterX;
    columnChosenHighlighter.visible = rowChosenHighlighter.visible = false;
    stage.addChild(columnChosenHighlighter, rowChosenHighlighter);
}

function createTableOutlines(a) {

    var outlines = new createjs.Shape();
    stage.addChild(outlines);
    var g = outlines.graphics;
    g.clear();
    g.setStrokeStyle(3);
    g.beginStroke(outlinesColor);

    //row lines
    for (var i = 1; i <= (maxCount + 1) ; i++) {
        g.moveTo(boxDim.width - (outlinesDim.height / 2), (boxDim.height * i) - (outlinesDim.height / 2));

        g.lineTo(a.canvas.outerWidth() - (outlinesDim.height / 2), (boxDim.height * i) - (outlinesDim.height / 2));
    }

    //column lines
    for (var i = 1; i <= (maxCount + 1) ; i++) {
        g.moveTo((boxDim.width * i) - (outlinesDim.width / 2), boxDim.height - (outlinesDim.width / 2));

        g.lineTo((boxDim.width * i) - (outlinesDim.width / 2), a.canvas.outerHeight() - (outlinesDim.width / 2));

    }

}

function createTableNumbers(a) {
    for (var i = 1; i <= maxCount; i++) {
        for (var j = 1; j <= maxCount; j++) {
            var num = i * j;
            var numName = (ROW + i) + (COLUMN + j);

            var tableNumCont = new createjs.Container();
            var tableNumBG = new createjs.Shape();
            tableNumBG.alpha = 0.1;
            var g = tableNumBG.graphics;
            g.beginFill(tableNumersBGColor);
            g.rect(0, 0, boxDim.width, boxDim.height);
            tableNumCont.x = (boxDim.width * i);
            tableNumCont.y = (boxDim.height * j);
            g.endFill();

            var tableNum = new createjs.Text(num.toString(), "normal 26px Arial", tableFontColor);
            tableNum.textBaseline = "middle";
            tableNum.textAlign = "center";
            tableNum.x = (boxDim.width / 2) - outlinesDim.width;
            tableNum.y = boxDim.height / 2;

            tableNumCont.addChild(tableNumBG, tableNum);


            (function (target, rowNumCont, columnNumCont) {

                target.onPress = function (evt) {
                    rowHeaderPressed(a, rowNumCont);
                    columnHeaderPressed(a, columnNumCont);
                }

                if (!createjs.Touch.isSupported()) {
                    target.onMouseOver = function (evt) {
                        a.canvas.css("cursor", "pointer");
                    }

                    target.onMouseOut = function (evt) {
                        a.canvas.css("cursor", "default");
                    }
                }

            })(tableNumCont, rowNumConts[(COLUMN + j)], columnNumConts[(ROW + i)]);

            tableNumbers[numName] = tableNum;

            stage.addChild(tableNumCont);

        }

    }

}



function columnHeaderPressed(a, columnHeader) {

    columnChosenHighlighterHeight = a.canvas.outerHeight() - boxDim.height;

    columnChosenHighlighter.x = columnHeader.x;
    columnChosenHighlighter.scaleY = 1;
    columnChosenHighlighter.visible = true;
    columnHeaderSelectedName = columnHeader.name;

    if (mobilePhone) {
        unHighlightTableNumber();
        columnChosenHighlighter.scaleY = columnChosenHighlighterHeight;
        highlightTableNumber();
    }
    else {
        TweenMax.to(columnChosenHighlighter, columnRowChosenHighlightSpeed, { scaleY: columnChosenHighlighterHeight, onStart: unHighlightTableNumber, onComplete: highlightTableNumber });
    }

}




function rowHeaderPressed(a, rowHeader) {

    var rowChosenHighlighterWidth = a.canvas.outerWidth() - boxDim.width;

    rowChosenHighlighter.y = rowHeader.y;
    rowChosenHighlighter.scaleX = 1;
    rowChosenHighlighter.visible = true;
    rowHeaderSelectedName = rowHeader.name;

    if (mobilePhone) {
        unHighlightTableNumber();
        rowChosenHighlighter.scaleX = rowChosenHighlighterWidth;
        highlightTableNumber();
    }
    else {
        TweenMax.to(rowChosenHighlighter, columnRowChosenHighlightSpeed, { scaleX: rowChosenHighlighterWidth, onStart: unHighlightTableNumber, onComplete: highlightTableNumber });
    }
}

function highlightTableNumber() {

    if (columnHeaderSelectedName && rowHeaderSelectedName) {
        var numName = columnHeaderSelectedName + rowHeaderSelectedName;
        tableNumbers[numName].color = highLightOrange;

        if (!mobilePhone) {
            TweenMax.to(tableNumbers[numName], selectedTableNumberScaleSpeed, { scaleX: selectedTableNumberScale, scaleY: selectedTableNumberScale, repeat: 1, yoyo: true });
        }

        selectedTableNumber = tableNumbers[numName];

    }

}

function unHighlightTableNumber() {
    if (selectedTableNumber) {
        selectedTableNumber.color = tableFontColor;
    }
}