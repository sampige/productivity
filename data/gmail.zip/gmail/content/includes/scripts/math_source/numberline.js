﻿var canvasWidth = 683,
    canvasHeight = 225,
    canvasMargin = 10,
// set false for subtraction equation
    additionEquation = true,
    preload,
    numberLineImage,
    startDraggerImage,
    finishDraggerImage,
    numberLine,
    numberLineBgColor = "#c0d4dd",
    startDragger,
    startDraggerContainer,
    finishDragger,
    finishDraggerContainer,
    dragStartX = 32,
    dragEndX = 657,
    tickWidth = 62.5,
    startDraggerInitX,
    finishDraggerInitX,
    startNum,
    finishNum,
    manifest = [
        { src: "number_line.png", id: "number_line" },
        { src: "start_dragger.png", id: "start_dragger" },
        { src: "finish_dragger.png", id: "finish_dragger" }
    ];

function initActivity(a) {

    a.canvas.attr('width', canvasWidth + canvasMargin * 2).attr('height', canvasHeight + canvasMargin * 2);
    // enabled mouse over / out events
    stage.enableMouseOver(10);
    stage.mouseMoveOutside = true;

    //// Use this instead to use tag loading
    //$.cachedScript(config.base + 'includes/jscript/preloadjs.js').done(function () {
    //preload = new createjs.PreloadJS(false);

    //// preload.onProgress = handleProgress;
    //preload.onComplete = handleComplete;
    //preload.onFileLoad = handleFileLoad;
    //preload.loadManifest(manifest);
    //});
    numberLineImage = new Image();
    numberLineImage.onload = createNumberLine;
    numberLineImage.crossOrigin = '';
    numberLineImage.src = a.imgBase + "number_line.png";
    startDraggerImage = new Image();
    startDraggerImage.onload = function () { createStartDragger(a); };
    startDraggerImage.crossOrigin = '';
    startDraggerImage.src = a.imgBase + "start_dragger.png";
    finishDraggerImage = new Image();
    finishDraggerImage.onload = function () { createFinishDragger(a); };
    finishDraggerImage.crossOrigin = '';
    finishDraggerImage.src = a.imgBase + "finish_dragger.png";
    
    a.updateStage();
}

function createNumberLine() {
    numberLine = new createjs.Bitmap(numberLineImage);
    numberLine.x = canvasMargin;
    numberLine.y = (canvasHeight / 2) - (numberLineImage.height / 2) + canvasMargin;
    stage.addChild(numberLine);
}

function createStartDragger(a) {
    startDraggerContainer = new createjs.Container();
    startDragger = new createjs.Bitmap(startDraggerImage);

    if (createjs.Touch.isSupported()) {
        var startDraggerContainerBG = new createjs.Shape();
        var g = startDraggerContainerBG.graphics;
        g.beginFill(numberLineBgColor);
        g.rect(0, 0, startDraggerImage.width, startDraggerImage.height);
        g.endFill();
        startDraggerContainer.addChild(startDraggerContainerBG);
    }

    startDraggerContainer.addChild(startDragger);
    startDraggerContainer.x = startDraggerInitX = dragStartX - (startDraggerImage.width / 2) + canvasMargin;
    startDraggerContainer.y = canvasHeight - startDraggerImage.height + canvasMargin;
    stage.addChild(startDraggerContainer);

    // wrapper function to provide scope for the event handlers:
    (function (target) {
        target.onPress = function (evt) {
            var offset = { x: target.x - evt.stageX };

            // add a handler to the event object's onMouseMove callback
            // this will be active until the user releases the mouse button:
            evt.onMouseMove = function (ev) {

                var newX = ev.stageX + offset.x;

                if ((newX >= startDraggerInitX) && (newX <= dragEndX - (startDraggerImage.width / 2)) && (additionEquation ? (newX <= finishDraggerContainer.x) : (newX >= finishDraggerContainer.x))) {
                    startNum = Math.round((newX + (startDraggerImage.width / 2) - startDraggerInitX) / tickWidth);
                    target.x = startDraggerInitX + (startNum * tickWidth);
                }
            }

            evt.onMouseUp = function (ev) {


            }

        }

        if (!createjs.Touch.isSupported()) {
            target.onMouseOver = function () {
                a.canvas.css("cursor", "pointer");
            }

            target.onMouseOut = function () {
                a.canvas.css("cursor", "default");
            }
        }

    })(startDraggerContainer);


}

function createFinishDragger(a) {
    finishDraggerContainer = new createjs.Container();
    finishDragger = new createjs.Bitmap(finishDraggerImage);

    if (createjs.Touch.isSupported()) {
        var finishDraggerContainerBG = new createjs.Shape();
        var g = finishDraggerContainerBG.graphics;
        g.beginFill(numberLineBgColor);
        g.rect(0, 0, finishDraggerImage.width, finishDraggerImage.height);
        g.endFill();
        finishDraggerContainer.addChild(finishDraggerContainerBG);
    }

    finishDraggerContainer.addChild(finishDragger);
    finishDraggerContainer.x = finishDraggerInitX = dragStartX - (finishDraggerImage.width / 2) + canvasMargin;
    finishDraggerContainer.y = canvasMargin;
    stage.addChild(finishDraggerContainer);

    // wrapper function to provide scope for the event handlers:
    (function (target) {
        target.onPress = function (evt) {

            var offset = { x: target.x - evt.stageX };

            // add a handler to the event object's onMouseMove callback
            // this will be active until the user releases the mouse button:
            evt.onMouseMove = function (ev) {

                var newX = ev.stageX + offset.x;
                if ((newX >= finishDraggerInitX) && (newX <= dragEndX - (finishDraggerImage.width / 2)) && (additionEquation ? (newX >= startDraggerContainer.x) : (newX <= startDraggerContainer.x))) {
                    finishNum = Math.round((newX + (finishDraggerImage.width / 2) - finishDraggerInitX) / tickWidth);
                    target.x = finishDraggerInitX + (finishNum * tickWidth);
                }

            }

            evt.onMouseUp = function (ev) {


            }

        }

        if (!createjs.Touch.isSupported()) {
            target.onMouseOver = function () {
                a.canvas.css("cursor", "pointer");
            }

            target.onMouseOut = function () {
                a.canvas.css("cursor", "default");
            }
        }

    })(finishDraggerContainer);

}