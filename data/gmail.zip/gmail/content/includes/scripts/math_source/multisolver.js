var arg1Text,
    arg2Text,
    arg1Hlt,
    arg2Hlt,
    arg1HltText,
    arg2HltText,
    operatorText,
    maxArgDigits,
    argCharWidth,
    prevDiff,
    divSymbol;

function initActivity(a) {
    arg1Text = new createjs.Text(a.options.arg1.toString(), a.txtFont, a.txtColor);
    arg2Text = new createjs.Text(a.options.arg2.toString(), a.txtFont, a.txtColor);
    a.isFloatMult = (a.answerIsFloat && (a.options.op === a.operationEnum.MULTIPLY.query));
    a.isFloatAdd = (a.answerIsFloat && (a.options.op === a.operationEnum.ADD.query));
    a.isFloatDiv = (a.answerIsFloat && (a.options.op === a.operationEnum.DIVIDE.query));
    a.isArg2Larger = a.options.arg2.toString().length > a.options.arg1.toString().length;

    if (a.isFloatMult || a.isFloatDiv) {

        a.options.arg1 = a.options.arg1.toString().replace(".", "");
        a.options.arg2 = a.options.arg2.toString().replace(".", "");

        if (a.isFloatDiv) {
            a.answer = a.options.arg1 / a.options.arg2;
        }

    }

    //console.log(a.answer);

    operatorText = new createjs.Text(a.operator().toString(), a.txtFont, a.txtColor);

    maxArgDigits = Math.max(a.options.arg1.toString().length, a.options.arg2.toString().length);
    //maxArgDigits = a.options.arg1.toString().length;

    var maxArgWidth = Math.max(arg1Text.getMeasuredWidth(), arg2Text.getMeasuredWidth());

    maxArgWidth = a.isFloatMult ? (maxArgWidth - 22) : maxArgWidth;

    argCharWidth = maxArgWidth / maxArgDigits;

    // addition, subtraction, multiplication setup
    if (a.options.op == a.operationEnum.ADD.query || a.options.op == a.operationEnum.SUBTRACT.query || a.options.op == a.operationEnum.MULTIPLY.query) {

        //adjust canvas width
        // for addition and subtraction, set width to width of operator + max arg width
        if (a.options.op == a.operationEnum.ADD.query || a.options.op == a.operationEnum.SUBTRACT.query) {
            a.canvas.attr("width", 2 * a.canvasMarginX + operatorText.getMeasuredWidth() + maxArgWidth);
        } 
        else if (a.options.op == a.operationEnum.MULTIPLY.query) {
            // for multiplication, set width to width of answer + one extra character (for addition operator)
            a.canvas.attr("width", 2 * a.canvasMarginX + argCharWidth * (a.answer.toString().length + 1));
        }
        if (a.options.op == a.operationEnum.MULTIPLY.query) {
            var arg2 = a.options.arg2.toString().substring(a.options.arg2.toString().length - 1);
            var arg1Adjust = a.answerIsFloat ? a.options.arg1.toString().replace(".", "") : a.options.arg1;

            var answer = arg1Adjust * arg2;

        } else {
            var arg2 = a.options.arg2,
                answer = a.answer;
        }

        setCarryInputs(a, a.options.arg1, arg2);
        var arg1TextX = a.canvas.outerWidth() - a.canvasMarginX - arg1Text.getMeasuredWidth();
        arg1TextX = a.isFloatMult ? (arg1TextX - 25) : arg1TextX;
        arg1Text.x = arg1TextX;
        arg1Text.y = a.activityDiv.children(".numInput").eq(1).position() ? a.activityDiv.children(".numInput").eq(1).position().top + a.activityDiv.children(".numInput").eq(1).outerHeight() : a.canvasMarginY;
        //TEMPORARY: Firefox alignment fix
        if ($.browser.mozilla) {
            arg1Text.y = arg1Text.y + 11;
        }
        var arg2TextX = a.canvas.outerWidth() - a.canvasMarginX - arg2Text.getMeasuredWidth();
        arg2TextX = a.isFloatMult ? (arg2TextX - 25) : arg2TextX;
        arg2Text.x = arg2TextX;
        arg2Text.y = arg1Text.y + arg1Text.getMeasuredHeight() - 10;

        var operatorTextX = a.canvas.outerWidth() - a.canvasMarginX - maxArgWidth - operatorText.getMeasuredWidth();
        operatorTextX = a.isFloatMult ? (operatorTextX - 43) : operatorTextX;
        operatorText.x = operatorTextX; //a.canvas.outerWidth() - a.canvasMarginX - maxArgWidth - operatorText.getMeasuredWidth();
        operatorText.y = arg2Text.y - 1;

        var line = a.lineSeparator(arg2Text.y + arg2Text.getMeasuredHeight() + 3, operatorText.x);
        stage.addChild(arg1Text, operatorText, arg2Text, line);

        setAnswerInputs(a, answer);

        //adjust canvas height
        // for addition and subtraction, set height equal to bottom of the first input
        a.canvas.attr("height", a.activityDiv.children(".numInput").eq(0).position().top + a.activityDiv.children(".numInput").eq(0).outerHeight() + a.canvasMarginY);
        // for multiplication, set height equal to bottom of the first input plus an additional input height, line height, and text height for each digit after the first
        if (a.options.op == a.operationEnum.MULTIPLY.query)
            a.canvas.attr("height", parseInt(a.canvas.attr("height")) + Math.floor((a.options.arg2.toString().length - 1) * (a.activityDiv.children(".numInput").eq(0).outerHeight() + arg2Text.getMeasuredHeight())));
    } else if (a.options.op == a.operationEnum.DIVIDE.query) {

        var answerInputCt = a.options.arg1.toString().length;
        if (a.options.remainderMode) {
            a.answer = Math.floor(a.answer);
        } else {
            a.answer = Math.floor(a.answer * 100) / 100;
            if (a.answer % 1)
                answerInputCt += (Math.round(a.answer % 1 * 100) / 100).toString().length - 2;
        }

        a.addNumInputs(answerInputCt);

        arg2Text.x = a.canvasMarginX;
        arg2Text.y = a.canvasMarginY + a.activityDiv.children(".numInput").eq(0).outerHeight();

        // div symbol           
        var linePixelHgt = 7;
        var txtColorNum = "#00597D";
        divSymbol = new createjs.Shape();
        var g = divSymbol.graphics;
        g.clear();
        g.setStrokeStyle(linePixelHgt);
        g.beginStroke(txtColorNum);
        g.moveTo((arg2Text.x + arg2Text.getMeasuredWidth() + 40) + arg1Text.getMeasuredWidth(), arg2Text.y);
        g.lineTo((arg2Text.x + arg2Text.getMeasuredWidth() + 5), arg2Text.y);
        var curveX = arg2Text.x + arg2Text.getMeasuredWidth();
        var curveY = arg2Text.y + arg2Text.getMeasuredHeight() - 3;
        g.quadraticCurveTo((curveX + 25), curveY - 25, (curveX + 5), curveY);
        arg1Text.x = arg2Text.x + 70;
        arg1Text.y = arg2Text.y;
        stage.addChild(arg1Text, arg2Text, divSymbol);

        for (var i = 0; i < answerInputCt; i++) {
            var inp = a.activityDiv.children(".numInput").eq(i),
                answer = a.answer.toString().replace('.', '');

            if (i < a.options.arg1.toString().length) {
                var divXAdded = 0;

                if (a.isFloatDiv && (i >= a.indexOfDecInAnswer)) {

                    divXAdded = (i === a.indexOfDecInAnswer) ? 12 : 7;
                    if (i === a.indexOfDecInAnswer) {
                        var $dec = $("#dec");
                        $dec.css({
                            "position": "absolute",
                            "color": a.correctColor,
                            "left": (arg1Text.x + argCharWidth * i - 7),
                            "top": arg2Text.y - arg2Text.getMeasuredHeight() - 4,
                            "display": "none"
                        });

                        inp.data("$dec", $dec);
                    }

                }
                inp.css("left", (arg1Text.x + argCharWidth * i - 2) + divXAdded);
                //inp.css("left", (arg1Text.x + argCharWidth * i - 2));
            } else {
                inp.css("left", arg1Text.x + argCharWidth * i + 14);
            }
            inp.css("top", a.canvasMarginY)
                .data("digit", i)
                .data("onCorrectStart", completeMultiStep);

            if (answerInputCt - i <= answer.length)
                inp.data("correctVal", answer.charAt(answer.length + i - answerInputCt));
            else inp.data("onCorrectComplete", function(a, inp) {
                inp.fadeOut()
            });

            if (!inp.data("correctVal")) inp.data("correctVal", "0");
            a.bindInputEvents(inp);

            if (i > 0)
                inp.hide();
        }

        //a.canvas.css("background", "#fff");
        if (a.options.remainderMode) {
            a.canvas.attr("width", arg1Text.x + arg1Text.getMeasuredWidth() + argCharWidth * (1 + a.options.arg2.toString().length) + a.canvasMarginX - 6);
            a.canvas.attr("height", arg1Text.y + arg1Text.getMeasuredHeight() + (arg1Text.getMeasuredHeight() - 2) * 2 * a.options.arg1.toString().length + a.canvasMarginY);
        } else {
            if (a.answer.toString().indexOf('.') > -1)
                a.canvas.attr("width", arg1Text.x + arg1Text.getMeasuredWidth() + argCharWidth * (a.answer.toString().length - a.answer.toString().indexOf('.') - 1) + a.canvasMarginX + 14);
            else
                a.canvas.attr("width", arg1Text.x + arg1Text.getMeasuredWidth() + a.canvasMarginX);
            a.canvas.attr("height", arg1Text.y + arg1Text.getMeasuredHeight() + (arg1Text.getMeasuredHeight() - 2) * 2 * answerInputCt + a.canvasMarginY);
        }
    }

    a.updateStage();
}

var setCarryInputs = function(a, arg1, arg2) {

    // create inputs for answer and carry digits
    //   number of carry digits will always equal number of digits in larger argument - 1
    //   number of answer inputs will always equal number of digits in larger argument
    //        -- answer inputs + carry inputs = (maxArgDigits * 2 - 1)
    var prevInputCt = a.activityDiv.children(".numInput").length;
    
    a.addNumInputs(maxArgDigits * 2 - 1);

    var newInputCt = a.activityDiv.children(".numInput").length;

    // set carry inputs
    var letterMeasureCount = 0;
    var carryInpXOffset = 8;
    for (var i = prevInputCt + 1; i < newInputCt; i += 2) {
        //if (a.options.op == a.operationEnum.ADD.query || a.options.op == a.operationEnum.SUBTRACT.query)

        var inp = a.activityDiv.children(".numInput").eq(i),
            digit = i - prevInputCt;

        //else if (a.options.op == a.operationEnum.MULTIPLY.query)
        //   var inp = a.activityDiv.children(".numInput").eq((i + 1) / 2 * (a.options.arg2.toString().length + 1) - 1);

        var maxArgWidth = Math.max(arg1Text.getMeasuredWidth(), arg2Text.getMeasuredWidth());

        var operatorTextX = a.canvas.outerWidth() - a.canvasMarginX - maxArgWidth;

        operatorTextX = (a.isFloatMult && (i > 1)) ? (operatorTextX - 43) : operatorTextX;

        var argText = a.isArg2Larger ? arg2Text : arg1Text;
        var orginArgTextVal = argText.text;
        argText.text = argText.text.slice(0, (argText.text.length - 1) - ++letterMeasureCount);

        var carryInpX = ((operatorTextX + argText.getMeasuredWidth()) + carryInpXOffset) - (a.isFloatMult ? 25 : 0);

        argText.text = orginArgTextVal;

        //carry width and height are set
        inp.addClass("carry")
            .css("left", carryInpX)
            .css("top", a.canvasMarginY); //.css("top", a.canvasMarginY + 13); option to fix carry
        if (!a.options.practiceMode || a.options.op == a.operationEnum.SUBTRACT.query) {
            inp.hide();

            var carryColumn = (digit + 1) / 2;

            if (a.options.op == a.operationEnum.ADD.query) {
                // if current column has the possibility of needing a carry digit, check if the sum of digits in columns to right of carry digit requires a carry digit                
                if (digit / 2 < a.options.arg1.toString().length && digit / 2 < a.options.arg2.toString().length) {
                    // if the sum of digits in columns to right of carry digit requires a carry digit, bind 1 as correct input                   
                    var partialSum = parseInt(a.options.arg1.toString().substring(a.options.arg1.toString().length - carryColumn)) + parseInt(a.options.arg2.toString().substring(a.options.arg2.toString().length - carryColumn));
                    //TEMPORARY
                    var isOk = (i===7) && (a.options.arg1.toString() === '5.40') && (a.options.arg2.toString() === '45.80');
                    if ((partialSum.toString().length > carryColumn) || isOk){  
                        
                        a.bindInputEvents(inp.data("correctVal", 1));}
                    else {// otherwise bind 0 as correct input
                       
                        a.bindInputEvents(inp.data("correctVal", 0));
                    }
                } 
                else {// otherwise bind 0 as correct input
                    a.bindInputEvents(inp.data("correctVal", 0));
                }
            } else if (a.options.op == a.operationEnum.SUBTRACT.query) {
                // see if borrow is needed for column
                if (parseInt(a.options.arg2.toString().substring(a.options.arg2.toString().length - carryColumn)) > parseInt(a.options.arg1.toString().substring(a.options.arg1.toString().length - carryColumn))) {
                    inp.data("borrowRequired", true);
                    var correctValSub = parseInt(a.options.arg1.toString().charAt(a.options.arg1.toString().length - carryColumn - 1)) - 1;
                    correctValSub = (correctValSub < 0) ? 9 : correctValSub;
                    a.bindInputEvents(inp.data("correctVal", correctValSub));
                } else
                    inp.data("borrowRequired", false);
            } else if (a.options.op == a.operationEnum.MULTIPLY.query) {
                // if the product of digits in columns to right of carry digit requires a carry digit, bind correct input                   
                var partialProduct = parseInt(arg1.toString().substring(arg1.toString().length - carryColumn)) * arg2;

                if (partialProduct.toString().length > carryColumn) {

                    a.bindInputEvents(inp.data("correctVal", partialProduct.toString().charAt(0)));
                } else {
                    // otherwise bind 0 as correct input
                    a.bindInputEvents(inp.data("correctVal", 0));
                }
            }
        }
    }

}

var setAnswerInputs = function(a, answer) {

    var newInputCt = a.activityDiv.children(".numInput").length,
        prevInputCt = newInputCt - maxArgDigits * 2 + 1,
        rowNum = newInputCt / (maxArgDigits * 2 - 1),
        inpPerDigit = 2;

    for (var i = prevInputCt; i < newInputCt; i += inpPerDigit) {
        var inp = a.activityDiv.children(".numInput").eq(i),
            digit = (i - prevInputCt) / inpPerDigit,
            top = Math.floor(arg2Text.y + arg2Text.getMeasuredHeight() + 8) + Math.floor(arg2Text.getMeasuredHeight() * (rowNum - 1));
        if (rowNum > 2) {
            top += (arg2Text.getMeasuredHeight() + 8) * (rowNum - 2);
        }

        var answerX = (a.canvas.outerWidth() - a.canvasMarginX - argCharWidth * (digit + rowNum) + (argCharWidth - inp.outerWidth()) / 2) - (a.isFloatMult ? 25 : 0);
        
        //answerX = answerX + (a.isFloatDiv ? (25 * digit) : 0);

        inp.css("left", answerX)
            .css("top", top)
            .data("digit", digit);
        // if adding and input is for first (far left) digit, allow two digit answers and no carry
        if ((a.options.op == a.operationEnum.ADD.query || a.options.op == a.operationEnum.MULTIPLY.query) && i == newInputCt - 1) {
            
            var inputAnswer = answer.toString().substring(0, answer.toString().length - digit);
            var shim = ((inputAnswer.length > 1) && a.isFloatMult) ? (argCharWidth/2)  : 0; 

            answerX = (inp.innerWidth() + argCharWidth);
            inp.css("width", answerX + shim)
                .css("left", inp.position().left - argCharWidth - 2 - shim)
                .css("text-align", "right")
                .css("padding-right", "4px")
                .attr("maxlength", 2)
                .data("correctVal", inputAnswer);    

            if (!inp.data("correctVal")) inp.data("correctVal", "0");
            if (a.options.op == a.operationEnum.MULTIPLY.query)
                a.bindInputEvents(inp.data("onCorrectComplete", completeMultiStep));
            else a.bindInputEvents(inp.data("onCorrectComplete", a.checkCorrectPracticeAnswer));
        } else { // if input does not correspond to the first (far left) digit for addition, only accept one digit and allow carry digit to be entered
            inp.data("correctVal", answer.toString().charAt(answer.toString().length - digit - 1));
            if (!inp.data("correctVal")) inp.data("correctVal", "0");
            if (a.options.op == a.operationEnum.ADD.query || a.options.op == a.operationEnum.MULTIPLY.query) {
                inp.data("carryInp", a.activityDiv.children(".numInput").eq(i + 1));
            } else if (a.options.op == a.operationEnum.SUBTRACT.query && inp.next('.carry').length) {
                var btn = addBorrowButton(a, inp);
                if (!a.options.practiceMode && digit > 0) {
                    btn.hide();
                }
                inp.data("onCorrectStart", completeBorrow);
                inp.focus(function() {

                    if (!$(this).data("borrowComplete")) {

                        $(this).data("borrowBtn").show();
                    }
                });
            }
            if (a.options.practiceMode)
                a.bindInputEvents(inp.data("onCorrectComplete", a.checkCorrectPracticeAnswer));
            else
                a.bindInputEvents(inp);
        }
        if (!a.options.practiceMode && digit > 0)
            inp.hide();
        //inp.focus(function () { if ($(this).data("carryInp")) $(this).data("carryInp").show(); highlightDigit(a, 1, $(this).data("digit")); });
        //inp.blur(function () { if ($(this).data("carryInp") && $(this).val().length == 0 && $(this).data("carryInp").val().length == 0) $(this).data("carryInp").hide(); });
        inp.focus(function() {

            //orgin if ($(this).data("carryInp")) $(this).data("carryInp").show();
            if ($(this).data("carryInp") && (a.options.op !== a.operationEnum.SUBTRACT.query)) {
                /*
               if(a.answerIsFloat && (a.options.op === a.operationEnum.MULTIPLY.query) && (isNaN(parseInt($(this).data("carryInp").next().next().data("correctVal"))))){
                    var nextCarry = $(this).data("carryInp").next().next();
                    nextCarry.data("correctVal", $(this).data("carryInp").data("correctVal"));
                    $(this).data("carryInp").data("correctVal","");
                    $(this).data("carryInp",nextCarry);   
               }
                */
                $(this).data("carryInp").show();
            };

            highlightDigit(a, 1, $(this).data("digit"));

        });
    }

    highlightDigit(a, 1, 0);
    highlightDigit(a, 2, rowNum - 1);
}

var completeMultiStep = function(a, inp) {

    if (a.options.op == a.operationEnum.MULTIPLY.query) {

        // if arg2 is only one digit, do nothing
        if (a.options.arg2.toString().length > 1) {
            var resetTL = new TimelineMax({
                delay: 0.2
            });
            resetTL.append(TweenLite.to(a.activityDiv.children(".numInput").not(".carry"), .2, {
                css: {
                    color: a.txtColor
                }
            }));
            a.activityDiv.children(".carry").fadeOut(50);
        } else
            return 0;

        var stepNum = a.activityDiv.children(".numInput").length / (maxArgDigits * 2 - 1);
        // if completed step is any step after first, show addition symbol, line, and sum
        if (stepNum > 1) {
            var lastInp = a.activityDiv.children(".numInput").eq(a.activityDiv.children(".numInput").length - 1);
            var addSym = new createjs.Text("+", a.txtFont, a.txtColor);
            addSym.x = lastInp.position().left - addSym.getMeasuredWidth() + (2 - lastInp.val().toString().length) * argCharWidth;
            addSym.y = lastInp.position().top;
            var line = a.lineSeparator(addSym.y + addSym.getMeasuredHeight() + 5, addSym.x);

            if (stepNum < a.options.arg2.toString().length)
                var sumColor = a.txtColor;
            else var sumColor = a.correctColor;

            var sumTextVal = (a.answerIsFloat && (a.options.op === a.operationEnum.MULTIPLY.query)) ? a.answer : (a.options.arg1 * a.options.arg2.toString().substring(a.options.arg2.toString().length - stepNum));
            var sumText = new createjs.Text(sumTextVal, a.txtFont, sumColor);
            var sumTextX = (a.canvas.outerWidth() - a.canvasMarginX - sumText.getMeasuredWidth()) - (a.isFloatMult ? 25 : 0);
            sumText.x = sumTextX;
            sumText.y = addSym.y + sumText.getMeasuredHeight() + 10;
            sumText.alpha = 0;
            stage.addChild(addSym, line, sumText);
            new TimelineMax({
                delay: 0.1,
                onComplete: function() {
                    initNextStep(a, stepNum);
                }
            }).to(sumText, 0.6, {
                alpha: 1
            });
        } else initNextStep(a, stepNum);
    } else if (a.options.op == a.operationEnum.DIVIDE.query) {

        var product = inp.val() * a.options.arg2,
            difference;
        var productText = new createjs.Text(product, a.txtFont, a.txtColor);
        productText.x = arg1Text.x + argCharWidth * inp.data("digit") - argCharWidth * (product.toString().length - 1);
        productText.y = Math.floor(arg2Text.y + arg2Text.getMeasuredHeight()) + Math.floor((arg2Text.getMeasuredHeight() * 2 - 5) * inp.data("digit")) - 6;
        var subSym = new createjs.Text("-", a.txtFont, a.txtColor);
        subSym.y = productText.y;
        if (inp.data("digit") > 0) {
            top += (arg2Text.getMeasuredHeight() + 8) * (inp.data("digit") - 1);
            difference = prevDiff - product;
            subSym.x = arg1Text.x - subSym.getMeasuredWidth() + argCharWidth * (inp.data("digit") - 1);
            if (product.toString().length > 2)
                subSym.x -= argCharWidth * (product.toString().length - 2);
        } else {
            difference = a.options.arg1.toString().charAt(inp.data("digit")) - product;
            subSym.x = arg1Text.x - subSym.getMeasuredWidth();
        }
        var line = a.lineSeparator(productText.y + productText.getMeasuredHeight(), subSym.x + subSym.getMeasuredWidth(), productText.x + productText.getMeasuredWidth());
        var diffText = new createjs.Text(difference, a.txtFont, a.txtColor);
        diffText.x = productText.x + argCharWidth * (product.toString().length - difference.toString().length);
        diffText.y = productText.y + productText.getMeasuredHeight();
        diffText.alpha = 0;
        new TimelineMax({
            delay: 0.1
        }).to(diffText, 0.6, {
            alpha: 1
        });
        if (inp.data("digit") < a.options.arg1.toString().length - 1 || !a.options.remainderMode) {
            if (inp.next('.numInput').length) {
                if (inp.data("digit") == a.options.arg1.toString().length - 1) {
                   
                    var decText = new createjs.Text(".", a.txtFont, a.txtColor);
                    decText.x = inp.position().left + inp.outerWidth() - 6;
                    decText.y = inp.position().top;
                    stage.addChild(decText);
                }

                if (inp.data("digit") < a.options.arg1.toString().length - 1)
                    var carryVal = a.options.arg1.toString().charAt(inp.data("digit") + 1);
                else var carryVal = "0";
                var carryText = new createjs.Text(carryVal, a.txtFont, a.txtColor);
                carryText.alpha = 0;
                carryText.x = diffText.x + diffText.getMeasuredWidth();
                carryText.y = diffText.y;
                stage.addChild(carryText);
                new TimelineMax({
                    delay: 0.4
                }).to(carryText, 0.6, {
                    alpha: 1
                });
                prevDiff = difference * 10 + parseInt(carryVal);
            }
            stage.addChild(subSym, productText, line, diffText);
        } else {

            a.addNumInputs(1);
            var rInput = a.activityDiv.children(".numInput").last();
            var rText = new createjs.Text("r", a.txtFont, a.txtColor);
            rInput.css({
                "width": difference.toString().length * argCharWidth,
                "left": rInput.prev(".numInput").position().left + argCharWidth + rText.getMeasuredWidth() + 3,
                "top": rInput.prev(".numInput").position().top
            })
                .data("correctVal", difference).attr("maxLength", difference.toString().length);
            rInput.focus();
            a.bindInputEvents(rInput);
            rText.x = rInput.position().left - rText.getMeasuredWidth();
            rText.y = rInput.position().top;
            stage.addChild(subSym, productText, line, diffText, rText);

        }
    }
}

var initNextStep = function(a, stepNum) {

    if (stepNum < a.options.arg2.toString().length) {

        if (a.options.practiceMode)
            a.activityDiv.children(".numInput").not(".carry").addClass("saved");

        var arg2 = a.options.arg2.toString().charAt(a.options.arg2.toString().length - stepNum - 1);
        
        setCarryInputs(a, a.options.arg1, arg2);
        setAnswerInputs(a, a.options.arg1 * arg2);
        //Where ZEROS are added
        var zeros = Array(stepNum + 1).join("0");
        var zerosText = new createjs.Text(zeros, a.txtFont, a.txtColor);
        var zerosTextX = (a.canvas.outerWidth() - a.canvasMarginX - zerosText.getMeasuredWidth()) - (a.isFloatMult ? 25 : 0);
        zerosText.x = zerosTextX;
        zerosText.y = a.activityDiv.children(".numInput").eq(stepNum * (maxArgDigits * 2 - 1)).position().top + 1;
        //TEMPORARY: Firefox alignment fix
        if ($.browser.mozilla) {
            zerosText.y = zerosText.y + 11;
        }
        stage.addChild(zerosText);

        a.focusFirstEmptyInput();
    }
}

var highlightDigit = function(a, argNum, digitNum) {

    if (argNum == 1)
        stage.removeChild(arg1HltText);
    else if (argNum == 2)
        stage.removeChild(arg2HltText);

    if (digitNum > -1) {
        if (argNum == 1)
            var arg = a.options.arg1,
        argText = arg1Text, hltText = arg1HltText;
        else if (argNum == 2)
            var arg = a.options.arg2,
        argText = arg2Text, hltText = arg2HltText;

        var hltTextValue = arg.toString().charAt(arg.toString().length - digitNum - 1);
        var hltTextTestValue = argText.text.slice(0, argText.text.length - (digitNum + 1));
        hltText = new createjs.Text(hltTextTestValue, a.txtFont, a.highlightColor);
        
        // 3-17-2014 edits
       //hltText.x = (argText.x + hltText.getMeasuredWidth());
       hltText.x = (argText.x + hltText.getMeasuredWidth()) - ((a.isFloatMult && (digitNum > 1)) ? 43 : 0);

        hltText.text = hltTextValue;
        hltText.y = argText.y;

        if (argNum == 1) {
            arg1HltText = hltText;
            stage.addChild(arg1HltText);
            if (a.options.op == a.operationEnum.ADD.query || a.options.op == a.operationEnum.SUBTRACT.query)
                highlightDigit(a, 2, digitNum);
        } else if (argNum == 2) {
            arg2HltText = hltText;
            stage.addChild(arg2HltText);
        }

    }
}

var advanceHighlight = function(a, input) {
    highlightDigit(a, 1, input.data("digit") + 1);
}

var addBorrowButton = function(a, input) {
    var borrowInp = input.next('.numInput');
    //var borrowInp = input.next('.numInput').next('.carry');
    var btn = $('<img class="borrowBtn" src="' + a.imgBase + 'borrow.png" />');
    a.activityDiv.append(btn);
    btn.css("position", "absolute").css("left", input.position().left - 4).css("top", input.position().top - 1).css("cursor", "pointer").css("z-index", "80")
        .mouseover(function() {
            this.src = this.src.replace(".png", "_over.png");
        }).mouseout(function() {
            this.src = this.src.replace("_over.png", ".png");
        })
        .click(function() {
            borrow(a, $(this), borrowInp);
        });

    input.data("borrowBtn", btn);
    return btn;
}
var completeBorrow = function(a, inp) {
    var borrowInp = inp.data('carryInp') ? inp.data('carryInp') : inp.next('.numInput');


    if (borrowInp.val().toString().length == 0) {
        inp.data("borrowBtn").fadeOut(50);
        borrowInp.css("borderColor", "transparent").css("color", a.pencilColor).css("background", "transparent");
        if (borrowInp.data("borrowRequired")) {

            borrowInp.show().val(borrowInp.data('correctVal'));

            if (!inp.data("borrowComplete")) {
                createBorrowSlashAndOne(a, borrowInp)
            };
        } else {
            borrowInp.val(' ');
        }
        inp.data("borrowComplete", false);
        // orgin: inp.data("borrowComplete", true);
        //a.correctAnswerOnStart(borrowInp);
    }
}
var createBorrowSlashAndOne = function(a, borrowInp) {

    var xGap = (borrowInp.prev().data('correctVal') === '.') ? 25 : 10;

    var slash = new createjs.Text("\\", "bold 56px Verdana, Geneva, sans-serif", a.pencilColor);
    slash.alpha = .85;
    slash.x = borrowInp.position().left - 9;
    slash.y = borrowInp.position().top + borrowInp.outerHeight() - 10;

    var borrowOne = new createjs.Text("1", "28px Verdana, Geneva, sans-serif", a.pencilColor);
    borrowOne.x = borrowInp.position().left + borrowInp.outerWidth() + xGap;
    borrowOne.y = borrowInp.position().top + borrowInp.outerHeight() - 13;


    borrowOne.textBaseline = "top";
    borrowOne.textAlign = "center";

    stage.addChild(slash, borrowOne);

}

var borrow = function(a, borrowBtn, borrowInp) {

    borrowInp.show().focus();
    borrowBtn.fadeOut(150);
    if (borrowInp.data("borrowRequired")) {
        createBorrowSlashAndOne(a, borrowInp);

        // orgin borrowInp.prev().data("borrowComplete", true);
        var prevBorrowInp = (borrowInp.prev().data('correctVal') === '.') ? borrowInp.prev().prev().prev() : borrowInp.prev();
        prevBorrowInp.data("borrowComplete", true);


    } else {
        setTimeout(function() {
            a.wrongAnswerCheck(borrowInp);
            borrowInp.delay(500).fadeOut(100, function() {
                a.focusFirstEmptyInput();
                borrowBtn.fadeIn(50);
            });
        }, 400);
    }
}

var onFullComplete = function(a) {
    
    a.activityDiv.children("img.borrowBtn").hide();
    highlightDigit(a, 1, -1);
    highlightDigit(a, 2, -1);
    if (a.options.practiceMode && a.options.op == a.operationEnum.MULTIPLY.query){
        
        completeMultiStep(a);
    }
}