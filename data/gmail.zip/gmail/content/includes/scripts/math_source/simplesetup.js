﻿function initActivity(a) {
    a.addNumInputs(2);
    var leftInput = a.activityDiv.children(".numInput").eq(0),
        rightInput = a.activityDiv.children(".numInput").eq(1);

    leftInput.css({ "left": a.canvasMarginX, "top": a.canvasMarginY, "width": a.options.arg1.toString().length * a.numInputClassWidth });
    leftInput.attr("maxlength", a.options.arg1.toString().length);
    a.bindInputEvents(leftInput.data("correctVal", a.options.arg1));

    operationObj = new createjs.Text(a.operator(), a.txtFont, a.txtColor);
    operationObj.x = leftInput.position().left + leftInput.outerWidth() + a.betweenNumSpace;
    operationObj.textBaseline = "middle";
    operationObj.y = leftInput.position().top + leftInput.outerHeight() / 2 - 2;
    stage.addChild(operationObj);

    rightInput.css({ "left" : operationObj.x + operationObj.getMeasuredWidth() + a.betweenNumSpace + 1,
        "top": a.canvasMarginY, "width": a.options.arg2.toString().length * a.numInputClassWidth });
    rightInput.attr("maxlength", a.options.arg2.toString().length);
    a.bindInputEvents(rightInput.data("correctVal", a.options.arg2));

    a.canvas.attr("height", rightInput.outerHeight() + (a.canvasMarginY * 2));
    a.canvas.attr("width", rightInput.position().left + rightInput.outerWidth() + a.canvasMarginX);

    a.updateStage();
}