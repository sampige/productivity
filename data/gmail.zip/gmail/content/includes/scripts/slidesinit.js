﻿
$(function() {
    $('ul.slideshowlist').slides({
        prevImage: '../../../img/left-arrow.png',
        nextImage: '../../../img/right-arrow.png',
        preloadImage: 'http://assets.gcflearnfree.org/site/slideshow/loading.gif'
    });
});