﻿// find all rollover images and add event functions
$(initLG);
var activeID = 0;

function initLG() {
    initHotspots();
}


function initHotspots() {
    // show popups on click
    //console.log('init_lg');
    $('.lgcanvas div.hs').click(function () { hsClick($(this)); }).each(function () { $(this).sprite({ fps: 30, no_of_frames: 91 }); });
    // show popups on mouseover
    //$('div.hs').mouseover(function() { hsOver($(this)); }).mouseout(function() { hsOut($(this)); });
}

function hsClick(hs) {
    //$('#labeledgraphic').children('div.pu').fadeOut(200);
    //$('img.hs').each(function() { $(this).attr('src', $(this).attr('src').replace('blue', 'orange')).css('z-index', '99'); });
    
    if (activeID > 0) {
        var currhs = $('#' + 'hs_' + activeID);
        $('#' + 'pu_' + activeID).fadeOut(200, function () { currhs.css('z-index', '99'); });
        currhs.spState(3).goToFrame(0).spStart().spSet('on_frame', { 19: function (obj) { obj.spStop().spSet('rewind', true); } });
    }

    var hsID = hs.attr('id').split('_')[1];
    if (activeID != hsID) {
        activeID = hsID;
        $('#' + 'pu_' + activeID).fadeIn(400);
        if (!hs.data('clicked'))
            hs.css('z-index', '101').goToFrame(0).spState(2).spSet('on_frame', { 15: function (obj) { obj.spStop(); } }).data('clicked', true);
        else
            hs.css('z-index', '101').spStart().spSet('on_frame', { 1: function (obj) { obj.spStop().spSet('rewind', false); } });
    }
    else activeID = 0;
}

//function hsOver(hs) {
//    var pu = $('#' + 'pu_' + hs.attr('id').split('_')[1]);
//    pu.fadeIn(500);
//}

//function hsOut(hs) {
//    var pu = $('#' + 'pu_' + hs.attr('id').split('_')[1]);
//    pu.fadeOut(200);
//}