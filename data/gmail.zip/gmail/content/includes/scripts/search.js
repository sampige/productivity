﻿$(function () {
    if ($('.searchBox').val() == "") {
        $('.search-button').attr('disabled', true);
    }

    $('.searchBox.new-search').keyup(function () {
        SearchValue($('.searchBox.new-search'));
    });

    $('.searchBox.search-footer').keyup(function () {
        SearchValue($('.searchBox.search-footer'));
    });
});

function SearchValue(searchBox) {
    if (searchBox.val() == "") {
        searchBox.next('.search-button').attr('disabled', true);
    }
    else {
        searchBox.next('.search-button').attr('disabled', false);
    }
}