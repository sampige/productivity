﻿$(function () {

    $(".dropDownListImage").click(function () { if ($(this).parent().find(".dropdown.pageHeadings").hasClass("activated")) { hidedropdown($(this).parent(), "list"); } else { dropdown($(this).parent(), "list"); } });
    $(".dropDownVideosImage").click(function () { if ($(this).parent().find(".dropdown.videos").hasClass("activated")) { hidedropdown($(this).parent(), "video"); } else { dropdown($(this).parent(), "video"); } });

});

function dropdown(dropdownList, type) {
    if (type == "list") {
        $(".collection-content").find(".dropdown.pageHeadings").css("display", "none").removeClass("activated");
        $(".collection-content").find(".list-arrow-up").css("display", "none");
        $(".collection-content").find(".dropdown.videos").css("display", "none").removeClass("activated");
        $(".collection-content").find(".video-arrow-up").css("display", "none");
        $(dropdownList).find(".dropdown.pageHeadings").css("display", "block").addClass("activated");
        $(dropdownList).find(".list-arrow-up").css("display", "block");
    }
    else {
        $(".collection-content").find(".dropdown.pageHeadings").css("display", "none").removeClass("activated");
        $(".collection-content").find(".list-arrow-up").css("display", "none");
        $(".collection-content").find(".dropdown.videos").css("display", "none").removeClass("activated");
        $(".collection-content").find(".video-arrow-up").css("display", "none");
        $(dropdownList).find(".dropdown.videos").css("display", "block").addClass("activated");
        $(dropdownList).find(".video-arrow-up").css("display", "block");
    }
}

function hidedropdown(dropdownList, type) {
    if (type == "list") {
        $(dropdownList).find(".dropdown.pageHeadings").css("display", "none").removeClass("activated");
        $(dropdownList).find(".list-arrow-up").css("display", "none");
    }
    else {
        $(dropdownList).find(".dropdown.videos").css("display", "none").removeClass("activated");
        $(dropdownList).find(".video-arrow-up").css("display", "none");
    }
}