/*
  File: jquery.iframe-resize.plugin.js
  Remarks: based on iframe-auto-height plugin at http://github.com/house9/jquery-iframe-auto-height
        original code from http://sonspring.com/journal/jquery-iframe-sizing
  Description: when the page loads set the width and height of an iframe based on the size of its contents
*/
manualSlidesInit = true;
(function ($) {
    $.fn.iframeAutoHeight = function (spec) {

        // set default option values
        var options = $.extend({
            heightOffset: 0,
            widthOffset: 0,
            minHeight: 0,
            minWidth: 0
        }, spec);

        // ******************************************************
        // iterate over the matched elements passed to the plugin ; return will make it chainable
        return this.each(function () {
            // resize
            function resize(iframe) {
                // get the iframe body height and set inline style to that plus a little
                var $body = $(iframe, window.top.document).contents().find('body');
                var newWidth = $body[0].scrollWidth + options.widthOffset;
                if ($body.width() < newWidth) newWidth = $body.width();
                if (newWidth < options.minWidth) {
                    newWidth = options.minWidth + options.widthOffset;
                }
                iframe.style.width = newWidth + 'px';

                var newHeight = $body[0].offsetHeight + options.heightOffset;
                if (newHeight < options.minHeight) {
                    newHeight = options.minHeight + options.heightOffset;
                }
                iframe.style.height = newHeight + 'px';
                // if iframe is inside of slideshow, adjust height of slideshow container
                if (typeof resizeSlideshow == 'function')
                    resizeSlideshow($(iframe).parents('.slideshow').first());
            } // END resize

                // Start timer when loaded.
                $(this).load(function () {
                    var iframe = this;
                    setTimeout(function () { resize(iframe); }, 200);
                });

                // Safari and Opera need a kick-start.
                var source = $(this).attr('src');
                $(this).attr('src', '');
                $(this).attr('src', source);


        }); // $(this).each(function () {
    }; // $.fn.iframeAutoHeight = function (options) {
}(jQuery)); // (function ($) {


$(function () { $('iframe.mathActivity').iframeAutoHeight(); });