﻿$(function () {
    //$(".textplus-videos .lesson-play-button").click(function () { $(".textplus-videos-list").toggle('slide', { direction: 'right' }, 400); LessonVideoMenu(); });
    $(".textplus-videos .lesson-play-button").click(function () { LessonVideoMenu() });
});

function LessonVideoMenu() {
    //-----First toggle call --- need to .textplus-videos-list {/*display: none;*/ } uncomment in textplus.css and comment out width: 30px; under .textplus-videos
    //var playClass = $(".textplus-videos img").attr("class").toString();
    //if (playClass != "lesson-play-button active") {
    //    $(".lesson-play-button").addClass("active");
    //    $('.textplus-videos .lesson-play-button').css({ transform: 'rotate(360deg)', '-moz-transform': 'rotate(360deg)', '-o-transform': 'rotate(360deg)', '-webkit-transform': 'rotate(360deg)', '-ms-transform': 'rotate(360deg)' });
    //}
    //else if (playClass == "lesson-play-button active") {
    //    $(".textplus-videos img").removeClass("active");
    //    $('.textplus-videos .lesson-play-button').css({ transform: 'rotate(180deg)', '-moz-transform': 'rotate(180deg)', '-o-transform': 'rotate(180deg)', '-webkit-transform': 'rotate(180deg)', '-ms-transform': 'rotate(180deg)' });
    //}

    //-----Second click call
    var numOfVideos = $(".textplus-videos-list li").length;
    if (!$(".lesson-play-button").hasClass("active")) {
        $(".lesson-play-button").addClass("active");
        $('.textplus-videos .lesson-play-button').css({ transform: 'rotate(360deg)', '-moz-transform': 'rotate(360deg)', '-o-transform': 'rotate(360deg)', '-webkit-transform': 'rotate(360deg)', '-ms-transform': 'rotate(360deg)' });
        if(numOfVideos == 1) { numOfVideos = 1.08 }
        $('.textplus-videos').animate({ width: numOfVideos * 215 }, 500);
    }
    else {
        $(".textplus-videos img").removeClass("active");
        $('.textplus-videos .lesson-play-button').css({ transform: 'rotate(180deg)', '-moz-transform': 'rotate(180deg)', '-o-transform': 'rotate(180deg)', '-webkit-transform': 'rotate(180deg)', '-ms-transform': 'rotate(180deg)' });
        $('.textplus-videos').animate({ width: '0' }, 500, function () { });        
    }

}
