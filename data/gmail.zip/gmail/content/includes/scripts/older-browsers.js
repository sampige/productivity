﻿$(function () {
    $('.search-button').attr('disabled', true);
    document.onkeydown = stopKey;
    $('.searchBox').keyup(function (event) {
        if ($('.searchBox').val != '') {
            $('.search-button').attr('disabled', false);
            document.onkeydown = startKey;
        }
        else {
            $('.search-button').attr('disabled', true);
        }
    })
});

$(addSearchEvents);

var searchPrompt = 'What can we teach you?'
var searchInProgress = 0;
var lastSearch = '';

function addSearchEvents() {
    $('.searchBox')
        .focus(function () { searchFocus($(this)); })
        .blur(function () { searchBlur($(this)); })
        .bind('keydown', function (event) { return searchKD(event); })
        .bind('keyup', function (event) { return searchKU(event); })
        .val(searchPrompt);
}

function searchFocus(e) {
    clearPrompt(e);
    if (lastSearch != '') {
        $('.search-button').attr('disabled', false);
        e.select();
    }
}
function searchBlur(e) {
    restorePrompt(e, searchPrompt);
}
function clearPrompt(e) {
    if (e.val() == searchPrompt) {
        e.val('');
    }
}

function restorePrompt(e) {
    if (e.val() == '') {
        e.val(searchPrompt);
        $('.search-button').attr('disabled', true);
    }
}

function searchKD(ev) {
    var code = -1;
    if (ev)
        code = ev.keyCode || ev.which;
}

function searchKU(ev) {
        if (searchInProgress == 0) {
            searchInProgress = 1;
            setTimeout('', 400);
        }    
}

function stopKey(evt) {
    var evt = (evt) ? evt : ((event) ? event : null);
    var node = (evt.target) ? evt.target : ((evt.srcElement) ? evt.srcElement : null);
    if ((evt.keyCode == 13)) { return false; }
}

function startKey(evt) {
    var evt = (evt) ? evt : ((event) ? event : null);
    var node = (evt.target) ? evt.target : ((evt.srcElement) ? evt.srcElement : null);
    if ((evt.keyCode == 13)) { return true; }
}