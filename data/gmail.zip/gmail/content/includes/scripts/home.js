﻿//var chosenVariation = cxApi.chooseVariation();
//$('#homepage').hide();

$(function () {
    //console.log(chosenVariation);
    //pageVariations[1]();
    //pageVariations[chosenVariation](); // Analytics experiment
    //$('#homepage').show();
    setInterval(advanceRotators, 5000);
});

var advanceRotators = function () {
    $('.rotator').each(function () {
        if ($(this).data('pause')) return true;
        // if initial position has not been set, set it to use for reset
        if (typeof $(this).children('ul').data('initPos') == 'undefined') {
            $(this).children('ul').data('initPos', $(this).children('ul').position().top);
            $(this).children('ul').bind("transitionend webkitTransitionEnd oTransitionEnd MSTransitionEnd", function () { $(this).addClass('noanimate'); $(this).css('top', $(this).data('initPos')); $(this).children('li').first().appendTo($(this)); });
        }

        if (Modernizr.csstransitions) {
            $(this).children('ul').removeClass('noanimate');
            // cycle one list item at a time
            $(this).children('ul').css('top', $(this).children('ul').position().top - $(this).children('ul').children('li').eq(1).position().top);
        }
        else {
            $(this).children('ul').animate({ top: $(this).children('ul').position().top - $(this).children('ul').children('li').eq(1).position().top }, {
                queue: false, duration: 800,
                complete: function () {
                    $(this).css('top', $(this).data('initPos')); $(this).children('li').first().appendTo($(this));
                }
            });
        }

        $(this).children('ul').children('li').eq(0).animate({ backgroundColor: "#00AEDB" }, { queue: false, duration: 800 });
        $(this).children('ul').children('li').eq(1).animate({ backgroundColor: "#26BAE0" }, { queue: false, duration: 800 });
        $(this).children('ul').children('li').eq(2).animate({ backgroundColor: "#40C2E4" }, { queue: false, duration: 800 });
        $(this).children('ul').children('li').eq(3).animate({ backgroundColor: "#59CAE8" }, { queue: false, duration: 800 });
        $(this).children('ul').children('li').eq(4).animate({ backgroundColor: "#73D3EB" }, { queue: false, duration: 800 });
        $(this).children('ul').children('li').eq(5).animate({ backgroundColor: "#8CDAEF" }, { queue: false, duration: 800 });
        $(this).children('ul').children('li').eq(6).animate({ backgroundColor: "#9DE1F3" }, { queue: false, duration: 800 });
        $(this).children('ul').children('li').eq(7).css("backgroundColor", "#B5E1EC");

    }).hover(function () { $(this).data('pause', true); }, function () { $(this).data('pause', false); });
}

window.Modernizr = function (a, b, c) { function w(a) { i.cssText = a } function x(a, b) { return w(prefixes.join(a + ";") + (b || "")) } function y(a, b) { return typeof a === b } function z(a, b) { return !!~("" + a).indexOf(b) } function A(a, b) { for (var d in a) { var e = a[d]; if (!z(e, "-") && i[e] !== c) return b == "pfx" ? e : !0 } return !1 } function B(a, b, d) { for (var e in a) { var f = b[a[e]]; if (f !== c) return d === !1 ? a[e] : y(f, "function") ? f.bind(d || b) : f } return !1 } function C(a, b, c) { var d = a.charAt(0).toUpperCase() + a.slice(1), e = (a + " " + m.join(d + " ") + d).split(" "); return y(b, "string") || y(b, "undefined") ? A(e, b) : (e = (a + " " + n.join(d + " ") + d).split(" "), B(e, b, c)) } var d = "2.7.1", e = {}, f = b.documentElement, g = "modernizr", h = b.createElement(g), i = h.style, j, k = {}.toString, l = "Webkit Moz O ms", m = l.split(" "), n = l.toLowerCase().split(" "), o = {}, p = {}, q = {}, r = [], s = r.slice, t, u = {}.hasOwnProperty, v; !y(u, "undefined") && !y(u.call, "undefined") ? v = function (a, b) { return u.call(a, b) } : v = function (a, b) { return b in a && y(a.constructor.prototype[b], "undefined") }, Function.prototype.bind || (Function.prototype.bind = function (b) { var c = this; if (typeof c != "function") throw new TypeError; var d = s.call(arguments, 1), e = function () { if (this instanceof e) { var a = function () { }; a.prototype = c.prototype; var f = new a, g = c.apply(f, d.concat(s.call(arguments))); return Object(g) === g ? g : f } return c.apply(b, d.concat(s.call(arguments))) }; return e }), o.csstransitions = function () { return C("transition") }; for (var D in o) v(o, D) && (t = D.toLowerCase(), e[t] = o[D](), r.push((e[t] ? "" : "no-") + t)); return e.addTest = function (a, b) { if (typeof a == "object") for (var d in a) v(a, d) && e.addTest(d, a[d]); else { a = a.toLowerCase(); if (e[a] !== c) return e; b = typeof b == "function" ? b() : b, typeof enableClasses != "undefined" && enableClasses && (f.className += " " + (b ? "" : "no-") + a), e[a] = b } return e }, w(""), h = j = null, e._version = d, e._domPrefixes = n, e._cssomPrefixes = m, e.testProp = function (a) { return A([a]) }, e.testAllProps = C, e }(this, this.document);



//var pageVariations = [
//  function () { },  // Original: Do nothing. This will render the default HTML.
//  function () {    // Variation 1: Work & Career image
//      $('#career .front, #career .back').css('background-image', "url('http://media.gcflearnfree.org/assets/tiles/home/work-and-career-2.png')");
//  },
//  function () {    // Variation 2: About Us blurb
//      $('#featured').removeClass('flip').addClass('text').html("<h3>About Us</h3><p>With step-by-step instruction, video tutorials, and hands-on interactives, you can learn for free with tutorials and online classes in more than 90 topics.</p>")
//  },
//  function () {    // Variation 3: Online Classes tile
//      changeTileToClasses($('#edl'));
//  },
//  function () {    // Variation 4: Most Popular rotator
//      $('#popular').children('div').first().children('a').append('<img class="dissolve" src="http://media.gcflearnfree.org/assets/tiles/home/most-popular.png" />');
//      var images = ["http://media.gcflearnfree.org/assets/tiles/home/most-popular.png", "http://media.gcflearnfree.org/assets/tiles/home/most-popular-2.png", "http://media.gcflearnfree.org/assets/tiles/home/most-popular-3.png", "http://media.gcflearnfree.org/assets/tiles/home/most-popular-4.png"]
//      setTimeout(function () { dissolveBackground($('#popular'), images, 0); }, 5000);
//  },
//  function () {    // Variation 5: All Topics at top
//      $('#alltopics').insertAfter('#popular').removeClass('wide').addClass('xwide');
//      $('#alltopics .front, #alltopics .back').css('background-image', "url('http://media.gcflearnfree.org/assets/tiles/home/alltopics-2.png')");
//      $('#featured').insertAfter('#mobile').addClass('small');
//      $('#popular').insertAfter('#featured').css('width', '228px');
//  },
//  function () {    // Variation 6: MS Office large
//      $('#office').insertAfter('#technology').addClass('tall');
//      updateFlipCopy($('#office'), "We have tutorials for Office 2000 through Office 2013. With step-by-step instruction, video tutorials, and hands-on interactives, if you have a Microsoft Office question, we have the answer.");
//      $('#reading').insertAfter('#math').removeClass('tall');
//      $('#reading .front, #reading .back').css('background-image', "url('http://media.gcflearnfree.org/assets/tiles/home/reading-2.png')");
//  },
//  function () {    // Variation 7: Combination
//      $('#office').insertAfter('#technology').addClass('xtall');
//      updateFlipCopy($('#office'), "We have tutorials for Office 2000 through Office 2013. With step-by-step instruction, video tutorials, and hands-on interactives, if you have a Microsoft Office question, we have the answer.");
//      $('#technology').addClass('xtall');
//      $('#reading').removeClass('tall').addClass('short').css('margin-bottom', '16px');
//      updateFlipCopy($('#reading'), "Study English, practice reading, and learn grammar.")
//      $('#math').removeClass('tall').addClass('short');
//      updateFlipCopy($('#math'), "Practice basic math skills with hands-on interactives.");
//      changeTileToClasses($('#edl').clone()).insertAfter('#edl');
//  }
//];

var changeTileToClasses = function(tile) {
    tile.attr('id', 'classes')
        .children('div').children('a').attr('href', 'http://classes.gcflearnfree.org')
                                      .children('h3').html('Online Classes')
                                      .next('p').html("FREE Online Classes in Microsoft Office - Get your Certificate of Completion today!");
    tile.children('div').eq(1).children('span.home-video').remove();
    tile.attachFlip();
    return tile;
}

var updateFlipCopy = function (tile, newCopy) {
    tile.children('div').children('a').children('p').html(newCopy);
}

var dissolveBackground = function (tile, imageArray, currentIndex) {
    var img = tile.children('div').first().children('a').children('img');
    var nextIndex = currentIndex + 1 === imageArray.length ? 0 : currentIndex + 1;

    img.attr('src', imageArray[currentIndex]).fadeIn(0);
    tile.children('.front').css('background-image', "url('" + imageArray[nextIndex] + "')");
    img.fadeOut(1000, "linear", function () { setTimeout(function () { dissolveBackground(tile, imageArray, nextIndex); }, 5000); });
}
