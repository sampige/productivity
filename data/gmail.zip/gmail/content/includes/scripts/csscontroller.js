﻿$(function () {
    //collection pages view and check/set cookies
    var nonseqCheck = nonseqCheckFunction();
    var cookies = document.cookie.split(';');
    var viewCookie = "";
    $.each(cookies, function (index, value) {
        if (value.indexOf('view=') != -1) {
            viewCookie = value;
        }
    });
    if (viewCookie.length != 0) {
        var cookieIndex = viewCookie.indexOf("=");
        var viewType = viewCookie.substring(cookieIndex + 1, cookieIndex + 11);
        if ((nonseqCheck == true && viewType == "videos") || ($('.videoCollectionIcon').css('display') == "none" && viewType == "videos")) { setCookie('thumbnails'); viewType = 'thumbnails'; }
        //var videoStyle = $('.collectionVideoView').css('display');
        if (viewType == 'list' || viewType == 'videos')
            changeViewType(viewType);
    }

});

function viewTypeClick(viewType) {
    changeViewType(viewType);
    setCookie(viewType);
}

function setCookie(viewType) {
    var date = new Date();
    var hours = date.getHours();
    date.setHours(hours + 2);
    document.cookie = "view=" + viewType + "; expires=" + date.toGMTString();
}

function changeViewType(viewType) {
    $(".collection-items").removeClass("thumbnails").removeClass("list").removeClass("videos").addClass(viewType);
    $(".thumbnailCollectionIcon img").attr("src", "img/tile-gray.png");
    $(".listCollectionIcon img").attr("src", "img/list-gray.png");
    $(".videoCollectionIcon img").attr("src", "img/video-gray.png");
    switch (viewType) {
        case ("thumbnails"):
            $(".collection-content").removeClass("video-view");
            $(".thumbnailCollectionIcon img").attr("src", "img/tile-orange.png");
            $(".collectionVideoView").css("display", "none");
            $(".learnmore").css("display", "block");
            if (nonseqCheckFunction() == false) {
                $(".dropDownVideosImage, .dropDownListImage").css("display", "block");
            }
            break;
        case("list") :
            $(".collection-content").removeClass("video-view");
            $(".listCollectionIcon img").attr("src", "img/list-orange.png");
            $(".collectionVideoView").css("display", "none");
            $(".learnmore").css("display", "none");
            $(".dropDownVideosImage, .dropDownListImage").css("display", "none");
            $(".collection-content").find(".dropdown.pageHeadings").css("display", "none").removeClass("activated");
            $(".collection-content").find(".list-arrow-up").css("display", "none");
            $(".collection-content").find(".dropdown.videos").css("display", "none").removeClass("activated");
            $(".collection-content").find(".video-arrow-up").css("display", "none");
            break;
        case ("videos"):
            $(".collection-content").addClass("video-view");
            $(".learnmore .collection-items").removeClass("videos").addClass("thumbnails");
            $(".videoCollectionIcon img").attr("src", "img/video-orange.png");
            $(".collectionVideoView").css("display", "block");
            $(".learnmore").css("display", "block");
            $(".dropDownVideosImage, .dropDownListImage").css("display", "none");
            $(".collection-content").find(".dropdown.pageHeadings").css("display", "none").removeClass("activated");
            $(".collection-content").find(".list-arrow-up").css("display", "none");
            $(".collection-content").find(".dropdown.videos").css("display", "none").removeClass("activated");
            $(".collection-content").find(".video-arrow-up").css("display", "none");
            break;
    }
}

function nonseqCheckFunction() {
    var className = $(".collection-items li").attr("class");
    if (className == "nonseq") {
        $(".videoCollectionIcon").css("display", "none");
        $(".dropDownVideosImage, .dropDownListImage").css("display", "none");
        return true;
    }
    else {
        return false;
    }
}