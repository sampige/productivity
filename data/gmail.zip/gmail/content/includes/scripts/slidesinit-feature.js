﻿$(function () {
    $('ul.slideshowlist').slides({
        preloadImage: 'http://assets.gcflearnfree.org/site/slideshow/loading.gif',
        play: 5000,
        hoverPause: true
    });
});