// browser detect
//var settings = navigator.userAgent.toLowerCase();
//var system = {
    //isWebkit: settings.split('webkit').length > 1,
    //isChrome: settings.split('chrome').length > 1,
    //isSafari: settings.split('safari').length > 1,
//}

// paths and files
//var storylinePath = 'http://assets.gcflearnfree.org/storyline/';
//var storylineHtml5 = 'story_html5.html';
//var storylineHtmlFlash = 'story.html';

// Webkit browsers (Safari & Chrome) get HTML5 version others get Flash version
//var storylineFile = (system.isWebkit || system.isSafari || system.isChrome) ? storylineHtml5 : storylineHtmlFlash;

// find iframes with storyline content and add 'src' attribute
$(storylineInit);

function storylineInit() {
    //$("iframe[data-content='storyline']").each(function (index, iframeElement) {
        //var $iframeElement = $(iframeElement);
        //var storylineFolder = $iframeElement.attr('id') + '/';
        //var storylineSrc = storylinePath + storylineFolder + storylineFile;
        //$iframeElement.attr('src', storylineSrc);

    //});
}