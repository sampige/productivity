﻿// find all rollover images and add event functions
$(initPage);
var errorImages = new Array();

function initPage() {
    addRolloverEffects();
    initTextboxes();
}
function addRolloverEffects() {
    // add effects for rollover images
    $('img.roe').mouseover(function() { imageOver($(this)); }).mouseout(function() { imageUp($(this)); imageOut($(this)); }).mousedown(function() { imageDown($(this)); }).mouseup(function() { imageUp($(this)); }).each(function() { preloadImageStates($(this).attr('src')); });
    // add effects for persistant rollover images (remain down until clicked off)
    $('img.roep').mouseover(function() { imageOver($(this)); }).mouseout(function() { imageOut($(this)); }).mousedown(function() { imageDown($(this), 1); }).each(function() { preloadImageStates($(this).attr('src')); });
}
function initTextboxes() {
    $(':text.smTextbox, :text.mdTextbox, :text.lgTextbox, :password.smTextbox, :password.mdTextbox, :password.lgTextbox').mouseover(function() { inputOver($(this)); }).mouseout(function() { inputOut($(this)); }).focus(function() { inputFocus($(this)); }).blur(function() { inputBlur($(this)); });
    var smTextbox = $(':text.smTextbox, :password.smTextbox')[0]
    if (smTextbox)
        preloadImageStates($(smTextbox).css('background-image'));
    var mdTextbox = $(':text.mdTextbox, :password.mdTextbox')[0]
    if (mdTextbox)
        preloadImageStates($(mdTextbox).css('background-image'));
    var lgTextbox = $(':text.lgTextbox, :password.lgTextbox')[0]
    if (lgTextbox)
        preloadImageStates($(lgTextbox).css('background-image'));
}

function imageOver(e) {
    if (e.src)
        e.src = e.src.replace('_off.png', '_over.png');
    else if (e.attr("src"))
        e.attr("src", e.attr("src").replace('_off.png', '_over.png'));
}
function imageOut(e) {
    if (e.src)
        e.src = e.src.replace('_over.png', '_off.png');
    else if (e.attr("src"))
        e.attr("src", e.attr("src").replace('_over.png', '_off.png'));
}
var currPressed;
function imageDown(e, resetPressed) {
    if (e.src)
        e.src = e.src.replace('_over.png', '_down.png');
    else if (e.attr("src"))
        e.attr("src", e.attr("src").replace('_over.png', '_down.png'));

    if (resetPressed) {
        if (currPressed) {
            imageUp(currPressed);
            if (currPressed.attr("src") != e.attr("src")) {
                imageOut(currPressed);
                currPressed = e;
            }
            else currPressed = null;
        }
        else currPressed = e;
    }
}
function imageUp(e) {
    if (e.src)
        e.src = e.src.replace('_down.png', '_over.png');
    else if (e.attr("src"))
        e.attr("src", e.attr("src").replace('_down.png', '_over.png'));
}
function imageInactive(e) {
    imageReset(e);
    e.src = e.src.replace('_off.png', '_inactive.png');
    e.style.cursor = 'default';
}
function imageActive(e) {
    e.src = e.src.replace('_inactive.png', '_off.png');
    e.style.cursor = 'pointer';
}
function inputOver(e) {
    e.css('background-image', e.css('background-image').replace('_off.png', '_over.png'));
}
function inputOut(e) {
    e.css('background-image', e.css('background-image').replace('_over.png', '_off.png'));
}
function inputFocus(e) {
    e.css('background-image', e.css('background-image').replace('_over.png', '_down.png').replace('_off.png', '_down.png'));
}
function inputBlur(e) {
    e.css('background-image', e.css('background-image').replace('_down.png', '_off.png'));
}
function preloadImageStates(src) {
    src = src.replace('url("', '').replace('")', '').replace('_off.png', '.png').replace('_over.png', '.png').replace('_down.png', '.png')
    preloadImages(src.replace('.png', '_off.png'), src.replace('.png', '_over.png'), src.replace('.png', '_down.png'));
}
function preloadImages() {
    var args_len = arguments.length;
    for (var i = args_len; i--; ) {
        $('<img />')
            .attr('src', arguments[i])
            .load(function() {
                $(elm('ImgHolder')).append($(this));
            });
    }
}

function printView() {
    $('body').addClass('printview');
    $('#header').addClass('noprint');
    $('#footerLinks').addClass('noprint');
}

jQuery.cachedScript = function (url, options) {
    // allow user to set any option except for dataType, cache, and url
    options = $.extend(options || {}, {
        dataType: "script",
        cache: true,
        url: url
    });

    // Use $.ajax() since it is more flexible than $.getScript
    // Return the jqXHR object so we can chain callbacks
    return jQuery.ajax(options);
};