﻿$(function () {
    $('li.dropdown').not('.current').children().children('h4').click(
        function () { $(this).parent().parent().children('ul').slideToggle(); }
    );

    $('h1, h2').css('color', $('.current').css('background-color'));

    //info page
    $('div.question').click(function () {
        clksect($(this));
    });

});


function clksect(e) {
    e.next('div.answer').slideToggle();
    var questionClassName = $(e).attr("class");
    if (questionClassName == "question active") {
        e.removeClass('active');
        e.css("background-image", 'url(' + "http://media.gcflearnfree.org/assets/icons/info/info-plus.png" + ')');
    }
    else {
        e.addClass('active');
        e.css("background-image", 'url(' + "http://media.gcflearnfree.org/assets/icons/info/info-minus.png" + ')');
    }
}