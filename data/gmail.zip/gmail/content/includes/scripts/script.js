﻿// find all rollover images and add event functions
$(initPage);

function initPage() {
    addRolloverEffects();
    if ($('#subjpage').length) setHoverFunctions();
}
function addRolloverEffects() {
    // add effects for rollover images
    $('img.roe').mouseover(function() { imageOver($(this)); }).mouseout(function() { imageUp($(this)); imageOut($(this)); }).mousedown(function() { imageDown($(this)); }).mouseup(function() { imageUp($(this)); }).each(function() { preloadImageStates($(this).attr('src')); });
    // add effects for persistant rollover images (remain down until clicked off)
    $('img.roep').mouseover(function() { imageOver($(this)); }).mouseout(function() { imageOut($(this)); }).mousedown(function() { imageDown($(this), 1); }).each(function() { preloadImageStates($(this).attr('src')); });
}
function imageOver(e) {
    if (e.src)
        e.src = e.src.replace('_off.png', '_over.png');
    else if (e.attr("src"))
        e.attr("src", e.attr("src").replace('_off.png', '_over.png'));
}
function imageOut(e) {
    if (e.src)
        e.src = e.src.replace('_over.png', '_off.png');
    else if (e.attr("src"))
        e.attr("src", e.attr("src").replace('_over.png', '_off.png'));
}
var currPressed;
function imageDown(e, resetPressed) {
    if (e.src)
        e.src = e.src.replace('_over.png', '_down.png');
    else if (e.attr("src"))
        e.attr("src", e.attr("src").replace('_over.png', '_down.png'));

    if (resetPressed) {
        if (currPressed) {
            imageUp(currPressed);
            if (currPressed.attr("src") != e.attr("src")) {
                imageOut(currPressed);
                currPressed = e;
            }
            else currPressed = null;
        }
        else currPressed = e;
    }
}
function imageUp(e) {
    if (e.src)
        e.src = e.src.replace('_down.png', '_over.png');
    else if (e.attr("src"))
        e.attr("src", e.attr("src").replace('_down.png', '_over.png'));
}
function imageInactive(e) {
    imageReset(e);
    e.src = e.src.replace('_off.png', '_inactive.png');
    e.style.cursor = 'default';
}
function imageActive(e) {
    e.src = e.src.replace('_inactive.png', '_off.png');
    e.style.cursor = 'pointer';
}
function inputOver(e) {
    e.css('background-image', e.css('background-image').replace('_off.png', '_over.png'));
}
function inputOut(e) {
    e.css('background-image', e.css('background-image').replace('_over.png', '_off.png'));
}
function inputFocus(e) {
    e.css('background-image', e.css('background-image').replace('_over.png', '_down.png').replace('_off.png', '_down.png'));
}
function inputBlur(e) {
    e.css('background-image', e.css('background-image').replace('_down.png', '_off.png'));
}
function preloadImageStates(src) {
    src = src.replace('url("', '').replace('")', '').replace('_off.png', '.png').replace('_over.png', '.png').replace('_down.png', '.png')
    preloadImages(src.replace('.png', '_off.png'), src.replace('.png', '_over.png'), src.replace('.png', '_down.png'));
}
function preloadImages() {
    var args_len = arguments.length;
    for (var i = args_len; i--; ) {
        $('<img />')
            .attr('src', arguments[i])
            .load(function() {
                $('#ImgHolder').append($(this));
            });
    }
}

function printView() {
    $('body').addClass('printview');
    $('#header').addClass('noprint');
    $('#footerLinks').addClass('noprint');
}


function setHoverFunctions() {
    // fix height of content frame so that bottom doesn't move when hovering if only one item on bottom row
    $('#content').height($('#content').height());
    $('#subjpage .subjitems div a').each(function() {
        $(this).mouseover(function() {
            $(this).parent().parent().addClass('over');
            $(this).parent().parent().mouseout(function() { $(this).removeClass('over'); });
        });
    });
}