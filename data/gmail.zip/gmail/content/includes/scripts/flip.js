﻿$(function () {
    $('.tile.flip').attachFlip();
});

(function ($) {
    $.fn.attachFlip = function () {
        if (typeof this.data('rotations') === 'undefined') {
            this.data('rotations', 0).hover(function () {
                flipTile($(this));
            }, function () {
                flipTile($(this));
            });
        }
        return this;
    };
})(jQuery);

var flipTile = function (tile) {

    var matrix = tile.children('.front').css('-moz-transform') || tile.children('.front').css('-webkit-transform') || tile.children('.front').css('msTransform') || tile.children('.front').css('-o-transform') || tile.children('.front').css('transform');
    if (!matrix) return;
    var currRot = matrix.indexOf('(') > -1 ? matrix.split('(')[1].split(',')[0] : 1;
    if (-1 < currRot && currRot < 1) {
        if (!tile.data('cancelrot'))
            tile.data('cancelrot', true);
        else
            tile.data('cancelrot', false);
    }
    else
        tile.data('cancelrot', false);

    var flipDelay = 500;
    if (tile.data('active') || tile.data('cancelrot')) {
        tile.data('rotations', tile.data('rotations') - 1);
        flipDelay = 0;
    }
    else {
        tile.data('rotations', tile.data('rotations') + 1)
        if (tile.data('rotations') % 2 == 0) {
            flipDelay = 0;
        }
    }

    tile.data('active', true);
    setTimeout(function () {
        if (tile.data('active')) {
            tile.data('active', false);
            var frontRot = tile.data('rotations') * -180;
            tile.children('.front').css({ '-webkit-transform': 'rotateY(' + frontRot + 'deg)', '-moz-transform': 'rotateY(' + frontRot + 'deg)', 'msTransform': 'rotateY(' + frontRot + 'deg)', '-o-transform': 'rotateY(' + frontRot + 'deg)', 'transform': 'rotateY(' + frontRot + 'deg)' });
            tile.children('.back').css({ '-webkit-transform': 'rotateY(' + (frontRot + 180) + 'deg)', '-moz-transform': 'rotateY(' + (frontRot + 180) + 'deg)', 'msTransform': 'rotateY(' + (frontRot + 180) + 'deg)', '-o-transform': 'rotateY(' + (frontRot + 180) + 'deg)', 'transform': 'rotateY(' + (frontRot + 180) + 'deg)' });
        }
    }, flipDelay);
};